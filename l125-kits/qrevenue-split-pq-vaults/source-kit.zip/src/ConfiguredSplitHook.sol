// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {QRevenueSplitHook} from './QRevenueSplitHook.sol';
import {IPoolManager} from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';
import {Currency} from '@uniswap/v4-core/src/types/Currency.sol';

// Vault identity and independent owner/key enrollment must be verified separately.
contract ConfiguredSplitHook is QRevenueSplitHook {
    constructor(IPoolManager manager_, address vault0_, address vault1_)
        QRevenueSplitHook(
            manager_,
            Currency.wrap(address(uint160(194866884977453722427157977695504402620791005730))),
            Currency.wrap(address(uint160(292300327466180583640736966543256603931186508595))),
            3000, 60,
            splitRecipients(vault0_, vault1_), splitWeights(), 100
        ) {
        require(block.chainid == 31337, 'Invalid chain ID');
    }
}
function splitRecipients(address a, address b) pure returns (address[] memory r) {
    r = new address[](2); r[0] = a; r[1] = b;
}
function splitWeights() pure returns (uint16[] memory w) {
    w = new uint16[](2); w[0] = 5000; w[1] = 5000;
}
