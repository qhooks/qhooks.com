// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {FullMath} from "@uniswap/v4-core/src/libraries/FullMath.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {
    BalanceDelta,
    BalanceDeltaLibrary
} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
import {Currency, CurrencyLibrary} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

import {QHookBase} from "./QHookBase.sol";

/// @notice Splits an immutable executed-swap fee among fixed recipients.
/// @dev Per-recipient floors favor the final recipient with all bounded dust.
/// Claims are minted directly; recipients are never called by this hook.
contract QRevenueSplitHook is QHookBase {
    using BalanceDeltaLibrary for BalanceDelta;
    using CurrencyLibrary for Currency;
    using PoolIdLibrary for PoolKey;

    error InvalidRecipientCount(uint256 count);
    error RecipientLengthMismatch(uint256 recipients, uint256 weights);
    error InvalidRecipient(uint256 index, address recipient);
    error DuplicateRecipient(uint256 firstIndex, uint256 secondIndex, address recipient);
    error InvalidWeight(uint256 index, uint16 weightBps);
    error InvalidTotalWeight(uint256 totalWeightBps);
    error InvalidFeeBps(uint16 feeBps);
    error ZeroAmountSpecified();
    error FeeDeltaOverflow(uint256 amount);

    event RevenueShareAccrued(
        PoolId indexed poolId,
        address indexed recipient,
        Currency indexed currency,
        uint256 amount
    );

    uint160 public constant REQUIRED_FLAGS =
        Hooks.AFTER_SWAP_FLAG | Hooks.AFTER_SWAP_RETURNS_DELTA_FLAG;
    uint16 public constant MAX_FEE_BPS = 1_000;
    uint256 internal constant BPS_DENOMINATOR = 10_000;
    uint256 internal constant MIN_RECIPIENTS = 2;
    uint256 internal constant MAX_RECIPIENTS = 8;

    address[] private _recipients;
    uint16[] private _weightsBps;
    uint16 public immutable feeBps;

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        address[] memory recipients_,
        uint16[] memory weightsBps_,
        uint16 feeBps_
    )
        QHookBase(
            manager_,
            currency0_,
            currency1_,
            poolFee_,
            tickSpacing_,
            REQUIRED_FLAGS
        )
    {
        uint256 count = recipients_.length;
        if (count != weightsBps_.length) {
            revert RecipientLengthMismatch(count, weightsBps_.length);
        }
        if (count < MIN_RECIPIENTS || count > MAX_RECIPIENTS) {
            revert InvalidRecipientCount(count);
        }
        if (feeBps_ == 0 || feeBps_ > MAX_FEE_BPS) {
            revert InvalidFeeBps(feeBps_);
        }

        uint256 totalWeight;
        for (uint256 i; i < count; ++i) {
            address recipient = recipients_[i];
            if (recipient == address(0) || recipient == address(this)) {
                revert InvalidRecipient(i, recipient);
            }
            uint16 weight = weightsBps_[i];
            if (weight == 0) revert InvalidWeight(i, weight);
            for (uint256 j; j < i; ++j) {
                if (recipients_[j] == recipient) {
                    revert DuplicateRecipient(j, i, recipient);
                }
            }
            totalWeight += weight;
        }
        if (totalWeight != BPS_DENOMINATOR) {
            revert InvalidTotalWeight(totalWeight);
        }

        _recipients = recipients_;
        _weightsBps = weightsBps_;
        feeBps = feeBps_;
    }

    function recipientCount() external view returns (uint256) {
        return _recipients.length;
    }

    function recipientAt(uint256 index) external view returns (address) {
        return _recipients[index];
    }

    function weightBpsAt(uint256 index) external view returns (uint16) {
        return _weightsBps[index];
    }

    function afterSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata params,
        BalanceDelta delta,
        bytes calldata
    ) external override onlyPoolManager(key) returns (bytes4, int128) {
        if (params.amountSpecified == 0) revert ZeroAmountSpecified();

        bool specifiedCurrencyIs0 = (params.amountSpecified < 0) == params.zeroForOne;
        Currency feeCurrency;
        int128 executedUnspecified;
        if (specifiedCurrencyIs0) {
            feeCurrency = key.currency1;
            executedUnspecified = delta.amount1();
        } else {
            feeCurrency = key.currency0;
            executedUnspecified = delta.amount0();
        }

        uint256 magnitude = executedUnspecified < 0
            ? uint256(-int256(executedUnspecified))
            : uint256(int256(executedUnspecified));
        uint256 totalFee = FullMath.mulDiv(magnitude, feeBps, BPS_DENOMINATOR);
        if (totalFee > uint256(uint128(type(int128).max))) {
            revert FeeDeltaOverflow(totalFee);
        }

        if (totalFee != 0) _mintShares(key, feeCurrency, totalFee);
        return (IHooks.afterSwap.selector, int128(uint128(totalFee)));
    }

    function _mintShares(PoolKey calldata key, Currency feeCurrency, uint256 totalFee)
        internal
    {
        uint256 remaining = totalFee;
        uint256 finalIndex = _recipients.length - 1;
        for (uint256 i; i < finalIndex; ++i) {
            uint256 share = FullMath.mulDiv(totalFee, _weightsBps[i], BPS_DENOMINATOR);
            remaining -= share;
            if (share != 0) {
                manager.mint(_recipients[i], feeCurrency.toId(), share);
                emit RevenueShareAccrued(
                    key.toId(), _recipients[i], feeCurrency, share
                );
            }
        }
        manager.mint(_recipients[finalIndex], feeCurrency.toId(), remaining);
        emit RevenueShareAccrued(
            key.toId(), _recipients[finalIndex], feeCurrency, remaining
        );
    }
}
