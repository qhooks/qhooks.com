// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {QCreatorFeeHook} from './QCreatorFeeHook.sol';
import {IPoolManager} from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';
import {Currency} from '@uniswap/v4-core/src/types/Currency.sol';
import {Hooks} from '@uniswap/v4-core/src/libraries/Hooks.sol';

// Generated pool policy; the launch pipeline must separately validate vault identity.
contract ConfiguredCreatorHook is QCreatorFeeHook {
    constructor(IPoolManager manager_, address vault_)
        QCreatorFeeHook(
            manager_,
            Currency.wrap(address(uint160(194866884977453722427157977695504402620791005730))),
            Currency.wrap(address(uint160(292300327466180583640736966543256603931186508595))),
            3000,
            60,
            Hooks.AFTER_SWAP_FLAG | Hooks.AFTER_SWAP_RETURNS_DELTA_FLAG,
            vault_,
            100
        ) {
        require(block.chainid == 31337, "Invalid chain ID");
    }
}
