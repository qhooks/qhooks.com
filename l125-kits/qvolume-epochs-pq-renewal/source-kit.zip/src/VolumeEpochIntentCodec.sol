// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @notice Strict, state-free serialization for opening a governed volume epoch.
/// @dev This library performs no signature, time, nonce, or onchain-state checks.
library VolumeEpochIntentCodec {
    uint32 internal constant SCHEMA_VERSION = 1;
    uint8 internal constant ACTION_OPEN_EPOCH = 1;
    uint256 internal constant ENCODED_LENGTH = 736;

    bytes32 internal constant MODULE_ID =
        0x51484f4f4b532f564f4c554d4545504f43482f56310000000000000000000000;
    bytes16 internal constant PQ_CONTEXT = 0x51484f4f4b532f564f4c554d452f5631;

    bytes32 internal constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 internal constant OPENING_TYPEHASH = keccak256(
        "QVolumeEpochOpening(uint32 schemaVersion,uint256 chainId,address controller,bytes32 moduleId,uint8 actionType,uint64 authEpoch,uint256 nonce,address manager,address hook,bytes32 poolId,uint256 oldEpoch,uint64 oldStartsAt,uint64 oldEndsAt,uint128 oldCap0For1,uint128 oldCap1For0,uint256 newEpoch,uint64 newStartsAt,uint64 newEndsAt,uint128 newCap0For1,uint128 newCap1For0,uint64 validAfter,uint64 validUntil,bytes32 policyHash)"
    );
    bytes32 internal constant NAME_HASH = keccak256("QHooks");
    bytes32 internal constant VERSION_HASH = keccak256("1");

    struct EpochOpening {
        uint32 schemaVersion;
        uint256 chainId;
        address controller;
        bytes32 moduleId;
        uint8 actionType;
        uint64 authEpoch;
        uint256 nonce;
        address manager;
        address hook;
        bytes32 poolId;
        uint256 oldEpoch;
        uint64 oldStartsAt;
        uint64 oldEndsAt;
        uint128 oldCap0For1;
        uint128 oldCap1For0;
        uint256 newEpoch;
        uint64 newStartsAt;
        uint64 newEndsAt;
        uint128 newCap0For1;
        uint128 newCap1For0;
        uint64 validAfter;
        uint64 validUntil;
        bytes32 policyHash;
    }

    error InvalidEncodedLength(uint256 actual);
    error NonZeroPadding(uint8 fieldIndex);
    error UnsupportedSchemaVersion(uint32 actual);
    error InvalidChainId();
    error InvalidController();
    error UnsupportedModule(bytes32 actual);
    error UnsupportedAction(uint8 actual);
    error InvalidManager();
    error InvalidHook();
    error TargetsNotDistinct(address controller, address manager, address hook);
    error InvalidPoolId();
    error InvalidOldEpochWindow(uint64 startsAt, uint64 endsAt);
    error InvalidNewEpochWindow(uint64 startsAt, uint64 endsAt);
    error InvalidEpochCaps(uint128 cap0For1, uint128 cap1For0);
    error InvalidEpochSequence(uint256 oldEpoch, uint256 newEpoch);
    error EpochsOverlap(uint64 oldEndsAt, uint64 newStartsAt);
    error EpochDurationChanged(uint256 oldDuration, uint256 newDuration);
    error InvalidAuthorizationWindow(uint64 validAfter, uint64 validUntil);
    error InvalidPolicyHash();

    function validate(EpochOpening memory opening) internal pure {
        if (opening.schemaVersion != SCHEMA_VERSION) {
            revert UnsupportedSchemaVersion(opening.schemaVersion);
        }
        if (opening.chainId == 0) revert InvalidChainId();
        if (opening.controller == address(0)) revert InvalidController();
        if (opening.moduleId != MODULE_ID) revert UnsupportedModule(opening.moduleId);
        if (opening.actionType != ACTION_OPEN_EPOCH) {
            revert UnsupportedAction(opening.actionType);
        }
        if (opening.manager == address(0)) revert InvalidManager();
        if (opening.hook == address(0)) revert InvalidHook();
        if (
            opening.controller == opening.manager || opening.controller == opening.hook
                || opening.manager == opening.hook
        ) {
            revert TargetsNotDistinct(opening.controller, opening.manager, opening.hook);
        }
        if (opening.poolId == bytes32(0)) revert InvalidPoolId();
        if (opening.oldEndsAt <= opening.oldStartsAt) {
            revert InvalidOldEpochWindow(opening.oldStartsAt, opening.oldEndsAt);
        }
        if (opening.newEndsAt <= opening.newStartsAt) {
            revert InvalidNewEpochWindow(opening.newStartsAt, opening.newEndsAt);
        }
        if (opening.oldCap0For1 == 0 || opening.oldCap1For0 == 0) {
            revert InvalidEpochCaps(opening.oldCap0For1, opening.oldCap1For0);
        }
        if (opening.newCap0For1 == 0 || opening.newCap1For0 == 0) {
            revert InvalidEpochCaps(opening.newCap0For1, opening.newCap1For0);
        }
        if (
            opening.oldEpoch == type(uint256).max
                || opening.newEpoch != opening.oldEpoch + 1
        ) {
            revert InvalidEpochSequence(opening.oldEpoch, opening.newEpoch);
        }
        if (opening.newStartsAt < opening.oldEndsAt) {
            revert EpochsOverlap(opening.oldEndsAt, opening.newStartsAt);
        }

        uint256 oldDuration = uint256(opening.oldEndsAt) - uint256(opening.oldStartsAt);
        uint256 newDuration = uint256(opening.newEndsAt) - uint256(opening.newStartsAt);
        if (newDuration != oldDuration) {
            revert EpochDurationChanged(oldDuration, newDuration);
        }
        if (opening.validUntil <= opening.validAfter) {
            revert InvalidAuthorizationWindow(opening.validAfter, opening.validUntil);
        }
        if (opening.policyHash == bytes32(0)) revert InvalidPolicyHash();
    }

    function encode(EpochOpening memory opening) internal pure returns (bytes memory) {
        validate(opening);
        return _encodeWordsUnchecked(opening);
    }

    function _encodeWordsUnchecked(EpochOpening memory opening)
        private
        pure
        returns (bytes memory)
    {
        bytes memory fields0Through7 = abi.encode(
            opening.schemaVersion,
            opening.chainId,
            opening.controller,
            opening.moduleId,
            opening.actionType,
            opening.authEpoch,
            opening.nonce,
            opening.manager
        );
        bytes memory fields8Through15 = abi.encode(
            opening.hook,
            opening.poolId,
            opening.oldEpoch,
            opening.oldStartsAt,
            opening.oldEndsAt,
            opening.oldCap0For1,
            opening.oldCap1For0,
            opening.newEpoch
        );
        bytes memory fields16Through22 = abi.encode(
            opening.newStartsAt,
            opening.newEndsAt,
            opening.newCap0For1,
            opening.newCap1For0,
            opening.validAfter,
            opening.validUntil,
            opening.policyHash
        );
        return bytes.concat(fields0Through7, fields8Through15, fields16Through22);
    }

    function decode(bytes memory encoded)
        internal
        pure
        returns (EpochOpening memory opening)
    {
        if (encoded.length != ENCODED_LENGTH) revert InvalidEncodedLength(encoded.length);

        _requireFits(encoded, 0, type(uint32).max);
        _requireFits(encoded, 2, type(uint160).max);
        _requireFits(encoded, 4, type(uint8).max);
        _requireFits(encoded, 5, type(uint64).max);
        _requireFits(encoded, 7, type(uint160).max);
        _requireFits(encoded, 8, type(uint160).max);
        _requireFits(encoded, 11, type(uint64).max);
        _requireFits(encoded, 12, type(uint64).max);
        _requireFits(encoded, 13, type(uint128).max);
        _requireFits(encoded, 14, type(uint128).max);
        _requireFits(encoded, 16, type(uint64).max);
        _requireFits(encoded, 17, type(uint64).max);
        _requireFits(encoded, 18, type(uint128).max);
        _requireFits(encoded, 19, type(uint128).max);
        _requireFits(encoded, 20, type(uint64).max);
        _requireFits(encoded, 21, type(uint64).max);

        opening = abi.decode(encoded, (EpochOpening));
        validate(opening);
    }

    function context() internal pure returns (bytes memory) {
        return abi.encodePacked(PQ_CONTEXT);
    }

    function structHash(EpochOpening memory opening) internal pure returns (bytes32) {
        validate(opening);
        return _structHashUnchecked(opening);
    }

    function domainSeparator(uint256 chainId, address controller)
        internal
        pure
        returns (bytes32)
    {
        if (chainId == 0) revert InvalidChainId();
        if (controller == address(0)) revert InvalidController();
        return _domainSeparatorUnchecked(chainId, controller);
    }

    function walletDigest(EpochOpening memory opening) internal pure returns (bytes32) {
        validate(opening);
        return keccak256(
            abi.encodePacked(
                hex"1901",
                _domainSeparatorUnchecked(opening.chainId, opening.controller),
                _structHashUnchecked(opening)
            )
        );
    }

    function _structHashUnchecked(EpochOpening memory opening)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            bytes.concat(abi.encode(OPENING_TYPEHASH), _encodeWordsUnchecked(opening))
        );
    }

    function _domainSeparatorUnchecked(uint256 chainId, address controller)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            abi.encode(DOMAIN_TYPEHASH, NAME_HASH, VERSION_HASH, chainId, controller)
        );
    }

    function _requireFits(bytes memory encoded, uint8 fieldIndex, uint256 maximum)
        private
        pure
    {
        uint256 word;
        assembly ("memory-safe") {
            word := mload(add(add(encoded, 0x20), mul(fieldIndex, 0x20)))
        }
        if (word > maximum) revert NonZeroPadding(fieldIndex);
    }
}
