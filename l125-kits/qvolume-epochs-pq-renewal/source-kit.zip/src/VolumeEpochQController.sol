// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {CanonicalKeyRegistry} from "./CanonicalKeyRegistry.sol";
import {GovernedVolumeEpochHook} from "./GovernedVolumeEpochHook.sol";
import {VolumeEpochIntentCodec} from "./VolumeEpochIntentCodec.sol";
import {ZKNOX_dilithium65} from "../vendor/ethdilithium/ZKNOX_dilithium65.sol";
import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

/// @notice Fixed-purpose wallet-and-ML-DSA controller for one governed volume-epoch hook.
/// @dev Local prototype only; enrollment consent, rotation, recovery, and production
///      PoolManager/helper identity selection remain outside this source scope.
contract VolumeEpochQController {
    using PoolIdLibrary for PoolKey;

    uint256 private constant RAW_PUBLIC_KEY_LENGTH = 1_952;
    uint256 private constant ML_DSA_SIGNATURE_LENGTH = 3_309;
    uint256 private constant SECP256K1_HALF_ORDER =
        0x7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0;

    bytes4 private constant RAW_VERIFY_SELECTOR =
        bytes4(keccak256("verify(bytes,bytes,bytes,bytes)"));
    bytes32 private constant MODULE_ID =
        0x51484f4f4b532f564f4c554d4545504f43482f56310000000000000000000000;

    address public immutable owner;
    bytes32 public immutable policyHash;
    uint64 public immutable authEpoch;
    IPoolManager public immutable manager;
    GovernedVolumeEpochHook public immutable hook;
    bytes32 public immutable poolId;
    CanonicalKeyRegistry public immutable registry;
    ZKNOX_dilithium65 public immutable verifier;
    bytes32 public immutable rawKeyId;
    address public immutable pointer0;
    address public immutable pointer1;

    uint256 public nextNonce;
    bool private _entered;

    error InvalidConfiguration();
    error InvalidRawKeyLength();
    error InvalidWindow();
    error InvalidNonce();
    error WalletAuthorizationFailed();
    error PQAuthorizationFailed();
    error ReentrantCall();

    event EpochOpeningAuthorized(
        bytes32 indexed poolId,
        uint256 indexed nonce,
        bytes32 messageHash,
        bytes32 walletDigest,
        uint256 oldEpoch,
        uint64 oldStartsAt,
        uint64 oldEndsAt,
        uint128 oldCap0For1,
        uint128 oldCap1For0,
        uint256 newEpoch,
        uint64 newStartsAt,
        uint64 newEndsAt,
        uint128 newCap0For1,
        uint128 newCap1For0
    );

    constructor(
        address helper,
        IPoolManager manager_,
        address owner_,
        bytes32 policyHash_,
        uint64 authEpoch_,
        bytes memory rawPublicKey,
        address currency0_,
        address currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        uint64 epochSeconds_,
        uint64 initialStartsAt_,
        uint64 initialEndsAt_,
        uint128 initialCap0For1_,
        uint128 initialCap1For0_,
        bytes32 hookSalt
    ) {
        if (rawPublicKey.length != RAW_PUBLIC_KEY_LENGTH) revert InvalidRawKeyLength();

        address self = address(this);
        address managerAddress = address(manager_);
        if (
            managerAddress == address(0) || managerAddress == self
                || managerAddress.code.length == 0 || owner_ == address(0) || owner_ == self
                || owner_.code.length != 0 || policyHash_ == bytes32(0) || currency0_ == address(0)
                || currency1_ == address(0) || currency0_ >= currency1_ || currency0_ == self
                || currency1_ == self || currency0_.code.length == 0 || currency1_.code.length == 0
        ) revert InvalidConfiguration();

        CanonicalKeyRegistry registry_ = new CanonicalKeyRegistry(helper);
        ZKNOX_dilithium65 verifier_ = new ZKNOX_dilithium65(helper);
        bytes memory handle = registry_.register(rawPublicKey);
        if (handle.length != 40) revert InvalidConfiguration();

        address pointer0_;
        address pointer1_;
        assembly ("memory-safe") {
            pointer0_ := shr(96, mload(add(handle, 32)))
            pointer1_ := shr(96, mload(add(handle, 52)))
        }
        if (pointer0_ == address(0) || pointer1_ == address(0) || pointer0_ == pointer1_) {
            revert InvalidConfiguration();
        }

        bytes32 rawKeyId_ = keccak256(rawPublicKey);
        bytes memory registeredHandle = registry_.lookup(rawKeyId_);
        if (
            registeredHandle.length != 40 || keccak256(registeredHandle) != keccak256(handle)
                || registry_.f1600Helper() != helper || verifier_.f1600Helper() != helper
                || address(registry_) == address(verifier_)
        ) revert InvalidConfiguration();

        Currency currency0 = Currency.wrap(currency0_);
        Currency currency1 = Currency.wrap(currency1_);
        GovernedVolumeEpochHook hook_ = new GovernedVolumeEpochHook{salt: hookSalt}(
            manager_,
            currency0,
            currency1,
            poolFee_,
            tickSpacing_,
            self,
            epochSeconds_,
            initialStartsAt_,
            initialEndsAt_,
            initialCap0For1_,
            initialCap1For0_
        );

        PoolKey memory key = PoolKey({
            currency0: currency0,
            currency1: currency1,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(hook_))
        });
        bytes32 poolId_ = PoolId.unwrap(key.toId());
        if (
            address(hook_).code.length == 0 || hook_.controller() != self
                || address(hook_.manager()) != managerAddress
                || Currency.unwrap(hook_.currency0()) != currency0_
                || Currency.unwrap(hook_.currency1()) != currency1_
                || hook_.poolFee() != poolFee_ || hook_.tickSpacing() != tickSpacing_
                || hook_.epochSeconds() != epochSeconds_ || hook_.poolId() != poolId_
                || hook_.currentEpoch() != 0 || hook_.initialized()
        ) revert InvalidConfiguration();

        (
            uint64 startsAt,
            uint64 endsAt,
            uint128 cap0For1,
            uint128 cap1For0,
            uint128 used0For1,
            uint128 used1For0,
            bool closed
        ) = hook_.epochs(0);
        if (
            startsAt != initialStartsAt_ || endsAt != initialEndsAt_
                || cap0For1 != initialCap0For1_ || cap1For0 != initialCap1For0_
                || used0For1 != 0 || used1For0 != 0 || closed
        ) revert InvalidConfiguration();

        owner = owner_;
        policyHash = policyHash_;
        authEpoch = authEpoch_;
        manager = manager_;
        hook = hook_;
        poolId = poolId_;
        registry = registry_;
        verifier = verifier_;
        rawKeyId = rawKeyId_;
        pointer0 = pointer0_;
        pointer1 = pointer1_;
    }

    /// @notice Return the immutable canonical expanded-key pointer pair.
    function keyHandle() public view returns (bytes memory) {
        return abi.encodePacked(pointer0, pointer1);
    }

    /// @notice Open the next bound epoch after wallet and PQ authorization.
    function openEpoch(
        uint256 expectedOldEpoch,
        uint64 expectedOldStartsAt,
        uint64 expectedOldEndsAt,
        uint128 expectedOldCap0For1,
        uint128 expectedOldCap1For0,
        uint256 newEpoch,
        uint64 newStartsAt,
        uint64 newEndsAt,
        uint128 newCap0For1,
        uint128 newCap1For0,
        uint256 nonce,
        uint64 validAfter,
        uint64 validUntil,
        bytes calldata walletSignature,
        bytes calldata pqSignature
    ) external {
        if (_entered) revert ReentrantCall();
        _entered = true;

        if (
            validUntil <= validAfter || block.timestamp < validAfter
                || block.timestamp >= validUntil
        ) revert InvalidWindow();
        if (nonce != nextNonce) revert InvalidNonce();

        VolumeEpochIntentCodec.EpochOpening memory opening =
            VolumeEpochIntentCodec.EpochOpening({
                schemaVersion: 1,
                chainId: block.chainid,
                controller: address(this),
                moduleId: MODULE_ID,
                actionType: 1,
                authEpoch: authEpoch,
                nonce: nonce,
                manager: address(manager),
                hook: address(hook),
                poolId: poolId,
                oldEpoch: expectedOldEpoch,
                oldStartsAt: expectedOldStartsAt,
                oldEndsAt: expectedOldEndsAt,
                oldCap0For1: expectedOldCap0For1,
                oldCap1For0: expectedOldCap1For0,
                newEpoch: newEpoch,
                newStartsAt: newStartsAt,
                newEndsAt: newEndsAt,
                newCap0For1: newCap0For1,
                newCap1For0: newCap1For0,
                validAfter: validAfter,
                validUntil: validUntil,
                policyHash: policyHash
            });

        bytes memory message = VolumeEpochIntentCodec.encode(opening);
        bytes32 walletDigest = VolumeEpochIntentCodec.walletDigest(opening);
        _verifyWallet(walletDigest, walletSignature);
        _verifyPQ(message, pqSignature);

        nextNonce = nonce + 1;
        hook.openEpoch(
            expectedOldEpoch,
            expectedOldStartsAt,
            expectedOldEndsAt,
            expectedOldCap0For1,
            expectedOldCap1For0,
            newEpoch,
            newStartsAt,
            newEndsAt,
            newCap0For1,
            newCap1For0
        );

        _entered = false;
        emit EpochOpeningAuthorized(
            poolId,
            nonce,
            keccak256(message),
            walletDigest,
            expectedOldEpoch,
            expectedOldStartsAt,
            expectedOldEndsAt,
            expectedOldCap0For1,
            expectedOldCap1For0,
            newEpoch,
            newStartsAt,
            newEndsAt,
            newCap0For1,
            newCap1For0
        );
    }

    function _verifyWallet(bytes32 digest, bytes calldata signature) private view {
        if (signature.length != 65) revert WalletAuthorizationFailed();

        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly ("memory-safe") {
            r := calldataload(signature.offset)
            s := calldataload(add(signature.offset, 32))
            v := byte(0, calldataload(add(signature.offset, 64)))
        }
        if (
            r == bytes32(0) || s == bytes32(0) || (v != 27 && v != 28)
                || uint256(s) > SECP256K1_HALF_ORDER
        ) revert WalletAuthorizationFailed();

        address recovered = ecrecover(digest, v, r, s);
        if (recovered == address(0) || recovered != owner) {
            revert WalletAuthorizationFailed();
        }
    }

    function _verifyPQ(bytes memory message, bytes calldata signature) private view {
        if (signature.length != ML_DSA_SIGNATURE_LENGTH) revert PQAuthorizationFailed();

        (bool success, bytes memory result) = address(verifier).staticcall(
            abi.encodeWithSelector(
                RAW_VERIFY_SELECTOR,
                keyHandle(),
                message,
                signature,
                VolumeEpochIntentCodec.context()
            )
        );
        if (!success || result.length != 32) revert PQAuthorizationFailed();

        uint256 resultWord;
        assembly ("memory-safe") {
            resultWord := mload(add(result, 32))
        }
        if (resultWord != 1) revert PQAuthorizationFailed();
    }
}
