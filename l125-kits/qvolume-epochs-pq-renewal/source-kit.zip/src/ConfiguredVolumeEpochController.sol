
// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import { VolumeEpochQController } from './VolumeEpochQController.sol';
import { IPoolManager } from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';

contract ConfiguredVolumeEpochController is VolumeEpochQController {
  constructor(
    address helper_,
    IPoolManager manager_,
    address owner_,
    bytes32 policyHash_,
    uint64 authEpoch_,
    bytes memory rawPublicKey_,
    address currency0_,
    address currency1_,
    bytes32 hookSalt_
  ) VolumeEpochQController(
    helper_,
    manager_,
    owner_,
    policyHash_,
    authEpoch_,
    rawPublicKey_,
    currency0_,
    currency1_,
    3000,
    60,
    3600,
    1700000000,
    1700003600,
    1000000000000000000,
    1000000000000000000,
    hookSalt_
  ) { require(block.chainid == 31337, 'Local chain only'); }
}
