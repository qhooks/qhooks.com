// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {CanonicalKeyRegistry} from "./CanonicalKeyRegistry.sol";
import {WithdrawalIntentCodec} from "./WithdrawalIntentCodec.sol";
import {ZKNOX_dilithium65} from "../vendor/ethdilithium/ZKNOX_dilithium65.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {IUnlockCallback} from "@uniswap/v4-core/src/interfaces/callback/IUnlockCallback.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";

/// @notice Claim-only local prototype requiring ECDSA and ML-DSA-65 authorization.
/// @dev This experiment supports exactly two immutable ERC20 claim currencies. It
///      does not implement enrollment consent, rotation, recovery, direct-asset
///      withdrawals, or production PoolManager identity validation.
contract ClaimQVault is IUnlockCallback {
    uint256 private constant RAW_PUBLIC_KEY_LENGTH = 1_952;
    uint256 private constant ML_DSA_SIGNATURE_LENGTH = 3_309;
    uint256 private constant CALLBACK_DATA_LENGTH = 160;
    uint256 private constant MAX_CLAIM_AMOUNT = uint256(uint128(type(int128).max));
    uint256 private constant SECP256K1_HALF_ORDER =
        0x7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0;

    bytes4 private constant RAW_VERIFY_SELECTOR =
        bytes4(keccak256("verify(bytes,bytes,bytes,bytes)"));
    bytes32 private constant MODULE_ID =
        0x51484f4f4b532f515641554c542f563100000000000000000000000000000000;
    bytes32 private constant CLAIM_CALLBACK_TAG =
        0x51484f4f4b532f434c41494d2f56310000000000000000000000000000000000;
    bytes32 private constant CLAIM_CALLBACK_OK =
        0x51484f4f4b532f434c41494d2f4f4b0000000000000000000000000000000000;

    IPoolManager public immutable manager;
    address public immutable owner;
    bytes32 public immutable policyHash;
    uint64 public immutable authEpoch;
    address public immutable currency0;
    address public immutable currency1;
    CanonicalKeyRegistry public immutable registry;
    ZKNOX_dilithium65 public immutable verifier;
    bytes32 public immutable rawKeyId;
    address public immutable pointer0;
    address public immutable pointer1;

    uint256 public nextNonce;

    bool private _entered;
    bool private _callbackActive;
    bytes32 private _callbackCommitment;

    error InvalidConfiguration();
    error InvalidRawKeyLength();
    error UnsupportedCurrency();
    error InvalidAmount();
    error InvalidRecipient();
    error InvalidWindow();
    error InvalidNonce();
    error WalletAuthorizationFailed();
    error PQAuthorizationFailed();
    error ReentrantCall();
    error InvalidCallback();
    error CallbackNotCompleted();

    event ClaimWithdrawn(
        address indexed currency,
        address indexed recipient,
        uint256 amount,
        uint256 nonce,
        bytes32 messageHash,
        bytes32 walletDigest
    );

    constructor(
        address helper,
        IPoolManager manager_,
        address owner_,
        bytes32 policyHash_,
        uint64 authEpoch_,
        bytes memory rawPublicKey,
        address currency0_,
        address currency1_
    ) {
        if (rawPublicKey.length != RAW_PUBLIC_KEY_LENGTH) revert InvalidRawKeyLength();

        address self = address(this);
        address managerAddress = address(manager_);
        if (
            managerAddress == address(0) || managerAddress == self
                || managerAddress.code.length == 0 || owner_ == address(0) || owner_ == self
                || owner_.code.length != 0 || policyHash_ == bytes32(0) || currency0_ == address(0)
                || currency1_ == address(0) || currency0_ >= currency1_ || currency0_ == self
                || currency1_ == self || currency0_.code.length == 0 || currency1_.code.length == 0
        ) revert InvalidConfiguration();

        CanonicalKeyRegistry registry_ = new CanonicalKeyRegistry(helper);
        ZKNOX_dilithium65 verifier_ = new ZKNOX_dilithium65(helper);
        bytes memory handle = registry_.register(rawPublicKey);
        if (handle.length != 40) revert InvalidConfiguration();

        address pointer0_;
        address pointer1_;
        assembly ("memory-safe") {
            pointer0_ := shr(96, mload(add(handle, 32)))
            pointer1_ := shr(96, mload(add(handle, 52)))
        }
        if (pointer0_ == address(0) || pointer1_ == address(0) || pointer0_ == pointer1_) {
            revert InvalidConfiguration();
        }

        manager = manager_;
        owner = owner_;
        policyHash = policyHash_;
        authEpoch = authEpoch_;
        currency0 = currency0_;
        currency1 = currency1_;
        registry = registry_;
        verifier = verifier_;
        rawKeyId = keccak256(rawPublicKey);
        pointer0 = pointer0_;
        pointer1 = pointer1_;
    }

    /// @notice Return the immutable canonical expanded-key pointer pair.
    function keyHandle() public view returns (bytes memory) {
        return abi.encodePacked(pointer0, pointer1);
    }

    /// @notice Burn PoolManager claims and transfer their exact underlying amount.
    function withdrawClaim(
        address currency,
        uint256 amount,
        address recipient,
        uint256 nonce,
        uint64 validAfter,
        uint64 validUntil,
        bytes calldata walletSignature,
        bytes calldata pqSignature
    ) external {
        if (_entered) revert ReentrantCall();
        _entered = true;

        if (currency != currency0 && currency != currency1) revert UnsupportedCurrency();
        if (amount == 0 || amount > MAX_CLAIM_AMOUNT) revert InvalidAmount();
        if (recipient == address(0) || recipient == address(this)) revert InvalidRecipient();
        if (
            validUntil <= validAfter || block.timestamp < validAfter
                || block.timestamp >= validUntil
        ) revert InvalidWindow();
        if (nonce != nextNonce) revert InvalidNonce();

        WithdrawalIntentCodec.Withdrawal memory withdrawal = WithdrawalIntentCodec.Withdrawal({
            schemaVersion: 1,
            chainId: block.chainid,
            vault: address(this),
            moduleId: MODULE_ID,
            actionType: 1,
            authEpoch: authEpoch,
            nonce: nonce,
            assetKind: 2,
            currency: currency,
            amount: amount,
            recipient: recipient,
            validAfter: validAfter,
            validUntil: validUntil,
            policyHash: policyHash
        });

        bytes memory message = WithdrawalIntentCodec.encode(withdrawal);
        bytes32 walletDigest = WithdrawalIntentCodec.walletDigest(withdrawal);
        _verifyWallet(walletDigest, walletSignature);
        _verifyPQ(message, pqSignature);

        nextNonce = nonce + 1;
        bytes memory callbackData =
            abi.encode(CLAIM_CALLBACK_TAG, nonce, currency, amount, recipient);
        if (callbackData.length != CALLBACK_DATA_LENGTH) revert InvalidCallback();

        _callbackActive = true;
        _callbackCommitment = keccak256(callbackData);
        bytes memory callbackResult = manager.unlock(callbackData);

        if (_callbackActive || _callbackCommitment != bytes32(0)) {
            revert CallbackNotCompleted();
        }
        if (callbackResult.length != 32) revert CallbackNotCompleted();
        bytes32 callbackMagic;
        assembly ("memory-safe") {
            callbackMagic := mload(add(callbackResult, 32))
        }
        if (callbackMagic != CLAIM_CALLBACK_OK) revert CallbackNotCompleted();

        _entered = false;
        emit ClaimWithdrawn(
            currency, recipient, amount, nonce, keccak256(message), walletDigest
        );
    }

    /// @inheritdoc IUnlockCallback
    function unlockCallback(bytes calldata data) external override returns (bytes memory) {
        if (
            msg.sender != address(manager) || !_entered || !_callbackActive
                || data.length != CALLBACK_DATA_LENGTH || keccak256(data) != _callbackCommitment
        ) revert InvalidCallback();

        (bytes32 tag,, address currency, uint256 amount, address recipient) =
            abi.decode(data, (bytes32, uint256, address, uint256, address));
        if (tag != CLAIM_CALLBACK_TAG) revert InvalidCallback();

        _callbackActive = false;
        _callbackCommitment = bytes32(0);

        manager.burn(address(this), uint160(currency), amount);
        manager.take(Currency.wrap(currency), recipient, amount);

        return abi.encode(CLAIM_CALLBACK_OK);
    }

    function _verifyWallet(bytes32 digest, bytes calldata signature) private view {
        if (signature.length != 65) revert WalletAuthorizationFailed();

        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly ("memory-safe") {
            r := calldataload(signature.offset)
            s := calldataload(add(signature.offset, 32))
            v := byte(0, calldataload(add(signature.offset, 64)))
        }
        if (
            r == bytes32(0) || s == bytes32(0) || (v != 27 && v != 28)
                || uint256(s) > SECP256K1_HALF_ORDER
        ) revert WalletAuthorizationFailed();

        address recovered = ecrecover(digest, v, r, s);
        if (recovered == address(0) || recovered != owner) {
            revert WalletAuthorizationFailed();
        }
    }

    function _verifyPQ(bytes memory message, bytes calldata signature) private view {
        if (signature.length != ML_DSA_SIGNATURE_LENGTH) revert PQAuthorizationFailed();

        (bool success, bytes memory result) = address(verifier).staticcall(
            abi.encodeWithSelector(
                RAW_VERIFY_SELECTOR,
                keyHandle(),
                message,
                signature,
                WithdrawalIntentCodec.context()
            )
        );
        if (!success || result.length != 32) revert PQAuthorizationFailed();

        uint256 resultWord;
        assembly ("memory-safe") {
            resultWord := mload(add(result, 32))
        }
        if (resultWord != 1) revert PQAuthorizationFailed();
    }
}
