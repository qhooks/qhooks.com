// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @notice Strict, state-free serialization helpers for the QVault V1 withdrawal intent.
/// @dev This library performs no signature verification, replay protection, authorization, or custody action.
library WithdrawalIntentCodec {
    uint32 internal constant SCHEMA_VERSION = 1;
    uint8 internal constant ACTION_WITHDRAWAL = 1;
    uint8 internal constant ASSET_NATIVE = 0;
    uint8 internal constant ASSET_ERC20 = 1;
    uint8 internal constant ASSET_CLAIM = 2;
    uint256 internal constant ENCODED_LENGTH = 448;

    bytes32 internal constant MODULE_ID =
        0x51484f4f4b532f515641554c542f563100000000000000000000000000000000;
    bytes14 internal constant PQ_CONTEXT = 0x51484f4f4b532f415554482f5631;

    bytes32 internal constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 internal constant WITHDRAWAL_TYPEHASH = keccak256(
        "QWithdrawal(uint32 schemaVersion,uint256 chainId,address vault,bytes32 moduleId,uint8 actionType,uint64 authEpoch,uint256 nonce,uint8 assetKind,address currency,uint256 amount,address recipient,uint64 validAfter,uint64 validUntil,bytes32 policyHash)"
    );
    bytes32 internal constant NAME_HASH = keccak256("QHooks");
    bytes32 internal constant VERSION_HASH = keccak256("1");

    struct Withdrawal {
        uint32 schemaVersion;
        uint256 chainId;
        address vault;
        bytes32 moduleId;
        uint8 actionType;
        uint64 authEpoch;
        uint256 nonce;
        uint8 assetKind;
        address currency;
        uint256 amount;
        address recipient;
        uint64 validAfter;
        uint64 validUntil;
        bytes32 policyHash;
    }

    error InvalidEncodedLength(uint256 actual);
    error NonZeroPadding(uint8 fieldIndex);
    error UnsupportedSchemaVersion(uint32 actual);
    error InvalidChainId();
    error InvalidVault();
    error UnsupportedModule(bytes32 actual);
    error UnsupportedAction(uint8 actual);
    error UnsupportedAssetKind(uint8 actual);
    error InvalidCurrency(uint8 assetKind, address currency);
    error InvalidAmount();
    error InvalidRecipient();
    error InvalidWindow(uint64 validAfter, uint64 validUntil);
    error InvalidPolicyHash();

    function validate(Withdrawal memory withdrawal) internal pure {
        if (withdrawal.schemaVersion != SCHEMA_VERSION) {
            revert UnsupportedSchemaVersion(withdrawal.schemaVersion);
        }
        if (withdrawal.chainId == 0) revert InvalidChainId();
        if (withdrawal.vault == address(0)) revert InvalidVault();
        if (withdrawal.moduleId != MODULE_ID) revert UnsupportedModule(withdrawal.moduleId);
        if (withdrawal.actionType != ACTION_WITHDRAWAL) revert UnsupportedAction(withdrawal.actionType);
        if (withdrawal.assetKind > ASSET_CLAIM) revert UnsupportedAssetKind(withdrawal.assetKind);
        if (
            (withdrawal.assetKind == ASSET_NATIVE && withdrawal.currency != address(0))
                || (withdrawal.assetKind == ASSET_ERC20 && withdrawal.currency == address(0))
        ) {
            revert InvalidCurrency(withdrawal.assetKind, withdrawal.currency);
        }
        if (withdrawal.amount == 0) revert InvalidAmount();
        if (withdrawal.recipient == address(0) || withdrawal.recipient == withdrawal.vault) {
            revert InvalidRecipient();
        }
        if (withdrawal.validUntil <= withdrawal.validAfter) {
            revert InvalidWindow(withdrawal.validAfter, withdrawal.validUntil);
        }
        if (withdrawal.policyHash == bytes32(0)) revert InvalidPolicyHash();
    }

    function encode(Withdrawal memory withdrawal) internal pure returns (bytes memory) {
        validate(withdrawal);
        return abi.encode(
            withdrawal.schemaVersion,
            withdrawal.chainId,
            withdrawal.vault,
            withdrawal.moduleId,
            withdrawal.actionType,
            withdrawal.authEpoch,
            withdrawal.nonce,
            withdrawal.assetKind,
            withdrawal.currency,
            withdrawal.amount,
            withdrawal.recipient,
            withdrawal.validAfter,
            withdrawal.validUntil,
            withdrawal.policyHash
        );
    }

    function decode(bytes memory encoded) internal pure returns (Withdrawal memory withdrawal) {
        if (encoded.length != ENCODED_LENGTH) revert InvalidEncodedLength(encoded.length);

        _requireFits(encoded, 0, type(uint32).max);
        _requireFits(encoded, 2, type(uint160).max);
        _requireFits(encoded, 4, type(uint8).max);
        _requireFits(encoded, 5, type(uint64).max);
        _requireFits(encoded, 7, type(uint8).max);
        _requireFits(encoded, 8, type(uint160).max);
        _requireFits(encoded, 10, type(uint160).max);
        _requireFits(encoded, 11, type(uint64).max);
        _requireFits(encoded, 12, type(uint64).max);

        withdrawal = abi.decode(encoded, (Withdrawal));
        validate(withdrawal);
    }

    function context() internal pure returns (bytes memory) {
        return abi.encodePacked(PQ_CONTEXT);
    }

    function structHash(Withdrawal memory withdrawal) internal pure returns (bytes32) {
        validate(withdrawal);
        return _structHashUnchecked(withdrawal);
    }

    function domainSeparator(uint256 chainId, address vault) internal pure returns (bytes32) {
        if (chainId == 0) revert InvalidChainId();
        if (vault == address(0)) revert InvalidVault();
        return _domainSeparatorUnchecked(chainId, vault);
    }

    function walletDigest(Withdrawal memory withdrawal) internal pure returns (bytes32) {
        validate(withdrawal);
        return keccak256(
            abi.encodePacked(
                hex"1901",
                _domainSeparatorUnchecked(withdrawal.chainId, withdrawal.vault),
                _structHashUnchecked(withdrawal)
            )
        );
    }

    function _structHashUnchecked(Withdrawal memory withdrawal) private pure returns (bytes32) {
        return keccak256(
            abi.encode(
                WITHDRAWAL_TYPEHASH,
                withdrawal.schemaVersion,
                withdrawal.chainId,
                withdrawal.vault,
                withdrawal.moduleId,
                withdrawal.actionType,
                withdrawal.authEpoch,
                withdrawal.nonce,
                withdrawal.assetKind,
                withdrawal.currency,
                withdrawal.amount,
                withdrawal.recipient,
                withdrawal.validAfter,
                withdrawal.validUntil,
                withdrawal.policyHash
            )
        );
    }

    function _domainSeparatorUnchecked(uint256 chainId, address vault) private pure returns (bytes32) {
        return keccak256(abi.encode(DOMAIN_TYPEHASH, NAME_HASH, VERSION_HASH, chainId, vault));
    }

    function _requireFits(bytes memory encoded, uint8 fieldIndex, uint256 maximum) private pure {
        uint256 word;
        assembly ("memory-safe") {
            word := mload(add(add(encoded, 0x20), mul(fieldIndex, 0x20)))
        }
        if (word > maximum) revert NonZeroPadding(fieldIndex);
    }
}
