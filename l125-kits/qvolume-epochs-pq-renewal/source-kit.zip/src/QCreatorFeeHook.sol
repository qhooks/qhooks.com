// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {FullMath} from "@uniswap/v4-core/src/libraries/FullMath.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {
    BalanceDelta,
    BalanceDeltaLibrary
} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
import {Currency, CurrencyLibrary} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

import {QHookBase} from "./QHookBase.sol";

/// @notice Local prototype that mints fixed creator-fee claims to one vault.
/// @dev This is an accounting prototype, not a live economic policy or custody
/// system. Swaps perform no signature verification.
contract QCreatorFeeHook is QHookBase {
    using BalanceDeltaLibrary for BalanceDelta;
    using CurrencyLibrary for Currency;

    error InvalidVault();
    error InvalidCreatorFeeBps(uint16 feeBps);
    error InvalidCreatorFlags(uint160 flags);
    error ZeroAmountSpecified();
    error FeeDeltaOverflow(uint256 amount);

    event CreatorFeeAccrued(
        PoolId indexed poolId,
        address indexed vault,
        Currency indexed currency,
        uint256 amount
    );

    uint16 public constant MAX_CREATOR_FEE_BPS = 1_000;
    uint256 internal constant BPS_DENOMINATOR = 10_000;
    uint160 public constant REQUIRED_FLAGS =
        Hooks.AFTER_SWAP_FLAG | Hooks.AFTER_SWAP_RETURNS_DELTA_FLAG;

    address public immutable vault;
    uint16 public immutable feeBps;

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        uint160 flags_,
        address vault_,
        uint16 feeBps_
    ) QHookBase(manager_, currency0_, currency1_, poolFee_, tickSpacing_, flags_) {
        if (flags_ != REQUIRED_FLAGS) revert InvalidCreatorFlags(flags_);
        if (vault_ == address(0) || vault_ == address(this)) revert InvalidVault();
        if (feeBps_ == 0 || feeBps_ > MAX_CREATOR_FEE_BPS) {
            revert InvalidCreatorFeeBps(feeBps_);
        }

        vault = vault_;
        feeBps = feeBps_;
    }

    function afterSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata params,
        BalanceDelta delta,
        bytes calldata
    ) external override onlyPoolManager(key) returns (bytes4, int128) {
        if (params.amountSpecified == 0) revert ZeroAmountSpecified();

        bool specifiedCurrencyIs0 = (params.amountSpecified < 0) == params.zeroForOne;
        Currency feeCurrency;
        int128 executedUnspecified;
        if (specifiedCurrencyIs0) {
            feeCurrency = key.currency1;
            executedUnspecified = delta.amount1();
        } else {
            feeCurrency = key.currency0;
            executedUnspecified = delta.amount0();
        }

        uint256 magnitude = executedUnspecified < 0
            ? uint256(-int256(executedUnspecified))
            : uint256(int256(executedUnspecified));
        uint256 feeAmount = FullMath.mulDiv(magnitude, feeBps, BPS_DENOMINATOR);
        if (feeAmount > uint256(uint128(type(int128).max))) {
            revert FeeDeltaOverflow(feeAmount);
        }

        if (feeAmount != 0) {
            manager.mint(vault, feeCurrency.toId(), feeAmount);
            emit CreatorFeeAccrued(key.toId(), vault, feeCurrency, feeAmount);
        }

        return (IHooks.afterSwap.selector, int128(uint128(feeAmount)));
    }
}
