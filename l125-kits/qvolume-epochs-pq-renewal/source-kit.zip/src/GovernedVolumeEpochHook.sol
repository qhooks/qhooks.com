// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {TransientStateLibrary} from "@uniswap/v4-core/src/libraries/TransientStateLibrary.sol";
import {
    BalanceDelta,
    BalanceDeltaLibrary
} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

import {QHookBase} from "./QHookBase.sol";

/// @notice Enforces separately capped, sequential trading-volume epochs for one pool.
/// @dev Any trader can consume the pool-wide raw-token allowance. The two directions
///      use separate units, and adjacent authorized windows can permit a boundary burst.
///      This provides no identity, anti-whale, fiat-risk, oracle, MEV, or availability guarantee.
contract GovernedVolumeEpochHook is QHookBase {
    using BalanceDeltaLibrary for BalanceDelta;
    using PoolIdLibrary for PoolKey;
    using TransientStateLibrary for IPoolManager;

    struct EpochState {
        uint64 startsAt;
        uint64 endsAt;
        uint128 cap0For1;
        uint128 cap1For0;
        uint128 used0For1;
        uint128 used1For0;
        bool closed;
    }

    error InvalidController(address controller);
    error InvalidEpochDuration(uint64 epochSeconds);
    error InvalidEpochWindow(uint64 startsAt, uint64 endsAt);
    error InvalidEpochCaps(uint128 cap0For1, uint128 cap1For0);
    error CallerNotController(address caller);
    error AlreadyInitialized();
    error HookNotInitialized();
    error PoolManagerUnlocked();
    error UnexpectedOldEpochState(
        uint256 expectedEpoch,
        uint64 expectedStartsAt,
        uint64 expectedEndsAt,
        uint128 expectedCap0For1,
        uint128 expectedCap1For0,
        uint256 actualEpoch,
        uint64 actualStartsAt,
        uint64 actualEndsAt,
        uint128 actualCap0For1,
        uint128 actualCap1For0
    );
    error EpochAlreadyClosed(uint256 epoch);
    error EpochNotEnded(uint256 epoch, uint64 endsAt, uint256 currentTime);
    error InvalidEpochSequence(uint256 currentEpoch, uint256 proposedEpoch);
    error EpochAlreadyOccupied(uint256 epoch);
    error InactiveEpoch(uint256 epoch, uint64 startsAt, uint64 endsAt, uint256 currentTime);
    error UnexpectedSwapDeltas(bool zeroForOne, int128 amount0, int128 amount1);
    error VolumeBudgetExceeded(
        bool zeroForOne,
        uint256 epoch,
        uint256 attemptedUsage,
        uint128 maximumUsage
    );

    event VolumeRecorded(
        bytes32 indexed poolId,
        uint256 indexed epoch,
        bool indexed zeroForOne,
        uint128 actualInput,
        uint128 directionalUsage
    );
    event EpochOpened(
        bytes32 indexed poolId,
        uint256 indexed oldEpoch,
        uint256 indexed newEpoch,
        uint64 oldStartsAt,
        uint64 oldEndsAt,
        uint128 oldCap0For1,
        uint128 oldCap1For0,
        uint128 finalizedUsed0For1,
        uint128 finalizedUsed1For0,
        uint64 newStartsAt,
        uint64 newEndsAt,
        uint128 newCap0For1,
        uint128 newCap1For0
    );

    uint160 public constant REQUIRED_FLAGS =
        Hooks.AFTER_INITIALIZE_FLAG | Hooks.AFTER_SWAP_FLAG;

    address public immutable controller;
    uint64 public immutable epochSeconds;
    bytes32 public immutable poolId;

    uint256 public currentEpoch;
    bool public initialized;
    mapping(uint256 epoch => EpochState state) public epochs;

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        address controller_,
        uint64 epochSeconds_,
        uint64 initialStartsAt_,
        uint64 initialEndsAt_,
        uint128 initialCap0For1_,
        uint128 initialCap1For0_
    )
        QHookBase(
            manager_,
            currency0_,
            currency1_,
            poolFee_,
            tickSpacing_,
            REQUIRED_FLAGS
        )
    {
        if (controller_ == address(0) || controller_ == address(this)) {
            revert InvalidController(controller_);
        }
        if (epochSeconds_ == 0) revert InvalidEpochDuration(epochSeconds_);
        if (
            initialEndsAt_ <= initialStartsAt_
                || uint256(initialEndsAt_) - uint256(initialStartsAt_) != epochSeconds_
        ) revert InvalidEpochWindow(initialStartsAt_, initialEndsAt_);
        if (initialCap0For1_ == 0 || initialCap1For0_ == 0) {
            revert InvalidEpochCaps(initialCap0For1_, initialCap1For0_);
        }

        controller = controller_;
        epochSeconds = epochSeconds_;
        epochs[0] = EpochState({
            startsAt: initialStartsAt_,
            endsAt: initialEndsAt_,
            cap0For1: initialCap0For1_,
            cap1For0: initialCap1For0_,
            used0For1: 0,
            used1For0: 0,
            closed: false
        });

        PoolKey memory key = PoolKey({
            currency0: currency0_,
            currency1: currency1_,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(this))
        });
        poolId = PoolId.unwrap(key.toId());
    }

    function afterInitialize(address, PoolKey calldata key, uint160, int24)
        external
        override
        onlyPoolManager(key)
        returns (bytes4)
    {
        if (initialized) revert AlreadyInitialized();
        initialized = true;
        return IHooks.afterInitialize.selector;
    }

    function afterSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata params,
        BalanceDelta delta,
        bytes calldata
    ) external override onlyPoolManager(key) returns (bytes4, int128) {
        if (!initialized) revert HookNotInitialized();

        uint256 epoch = currentEpoch;
        EpochState storage state = epochs[epoch];
        if (state.closed) revert EpochAlreadyClosed(epoch);
        if (block.timestamp < state.startsAt || block.timestamp >= state.endsAt) {
            revert InactiveEpoch(epoch, state.startsAt, state.endsAt, block.timestamp);
        }

        int128 amount0 = delta.amount0();
        int128 amount1 = delta.amount1();
        bool zeroForOne = params.zeroForOne;
        uint128 actualInput;
        if (amount0 == 0 && amount1 == 0) {
            actualInput = 0;
        } else if (zeroForOne) {
            if (amount0 >= 0 || amount1 < 0) {
                revert UnexpectedSwapDeltas(true, amount0, amount1);
            }
            actualInput = uint128(uint256(-int256(amount0)));
        } else {
            if (amount1 >= 0 || amount0 < 0) {
                revert UnexpectedSwapDeltas(false, amount0, amount1);
            }
            actualInput = uint128(uint256(-int256(amount1)));
        }

        if (zeroForOne) {
            uint256 nextUsage = uint256(state.used0For1) + actualInput;
            if (nextUsage > state.cap0For1) {
                revert VolumeBudgetExceeded(true, epoch, nextUsage, state.cap0For1);
            }
            state.used0For1 = uint128(nextUsage);
            emit VolumeRecorded(poolId, epoch, true, actualInput, uint128(nextUsage));
        } else {
            uint256 nextUsage = uint256(state.used1For0) + actualInput;
            if (nextUsage > state.cap1For0) {
                revert VolumeBudgetExceeded(false, epoch, nextUsage, state.cap1For0);
            }
            state.used1For0 = uint128(nextUsage);
            emit VolumeRecorded(poolId, epoch, false, actualInput, uint128(nextUsage));
        }

        return (IHooks.afterSwap.selector, 0);
    }

    function openEpoch(
        uint256 expectedOldEpoch,
        uint64 expectedOldStartsAt,
        uint64 expectedOldEndsAt,
        uint128 expectedOldCap0For1,
        uint128 expectedOldCap1For0,
        uint256 newEpoch,
        uint64 newStartsAt,
        uint64 newEndsAt,
        uint128 newCap0For1,
        uint128 newCap1For0
    ) external {
        if (msg.sender != controller) revert CallerNotController(msg.sender);
        if (!initialized) revert HookNotInitialized();
        if (manager.isUnlocked()) revert PoolManagerUnlocked();

        uint256 oldEpoch = currentEpoch;
        EpochState storage oldState = epochs[oldEpoch];
        if (
            expectedOldEpoch != oldEpoch || expectedOldStartsAt != oldState.startsAt
                || expectedOldEndsAt != oldState.endsAt
                || expectedOldCap0For1 != oldState.cap0For1
                || expectedOldCap1For0 != oldState.cap1For0
        ) {
            revert UnexpectedOldEpochState(
                expectedOldEpoch,
                expectedOldStartsAt,
                expectedOldEndsAt,
                expectedOldCap0For1,
                expectedOldCap1For0,
                oldEpoch,
                oldState.startsAt,
                oldState.endsAt,
                oldState.cap0For1,
                oldState.cap1For0
            );
        }
        if (oldState.closed) revert EpochAlreadyClosed(oldEpoch);
        if (block.timestamp < oldState.endsAt) {
            revert EpochNotEnded(oldEpoch, oldState.endsAt, block.timestamp);
        }
        if (oldEpoch == type(uint256).max || newEpoch != oldEpoch + 1) {
            revert InvalidEpochSequence(oldEpoch, newEpoch);
        }
        if (
            newEndsAt <= newStartsAt
                || uint256(newEndsAt) - uint256(newStartsAt) != epochSeconds
                || newStartsAt < oldState.endsAt || newEndsAt <= block.timestamp
        ) revert InvalidEpochWindow(newStartsAt, newEndsAt);
        if (newCap0For1 == 0 || newCap1For0 == 0) {
            revert InvalidEpochCaps(newCap0For1, newCap1For0);
        }

        EpochState storage newState = epochs[newEpoch];
        if (
            newState.startsAt != 0 || newState.endsAt != 0 || newState.cap0For1 != 0
                || newState.cap1For0 != 0 || newState.used0For1 != 0
                || newState.used1For0 != 0 || newState.closed
        ) revert EpochAlreadyOccupied(newEpoch);

        oldState.closed = true;
        newState.startsAt = newStartsAt;
        newState.endsAt = newEndsAt;
        newState.cap0For1 = newCap0For1;
        newState.cap1For0 = newCap1For0;
        newState.used0For1 = 0;
        newState.used1For0 = 0;
        newState.closed = false;
        currentEpoch = newEpoch;

        emit EpochOpened(
            poolId,
            oldEpoch,
            newEpoch,
            oldState.startsAt,
            oldState.endsAt,
            oldState.cap0For1,
            oldState.cap1For0,
            oldState.used0For1,
            oldState.used1For0,
            newStartsAt,
            newEndsAt,
            newCap0For1,
            newCap1For0
        );
    }
}
