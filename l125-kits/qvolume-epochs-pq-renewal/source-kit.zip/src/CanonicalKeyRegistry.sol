// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

// Public-key expansion follows the MIT-licensed ML-DSA-65 expansion in
// ZKNoxHQ/ETHDILITHIUM at 4c370bb5ff90d98e1ce8fb96f867126f0fbb9046.
// The helper-backed Keccak-f[1600] interface is inherited from the pinned
// ZKNOX / Fireblocks-derived verifier closure.

import {SSTORE2} from "../vendor/sstore2/SSTORE2.sol";
import {f1600Fast170, shake256Any} from "../vendor/ethdilithium/ZKNOX_shake_fast.sol";

/// @notice Public-fixture research registry that derives the verifier's exact
///         expanded ML-DSA-65 key representation from a raw FIPS public key.
/// @dev This establishes representation identity only. It does not authorize
///      enrollment or rotation for any consuming vault.
contract CanonicalKeyRegistry {
    uint256 private constant RAW_KEY_BYTES = 1952;
    uint256 private constant HALF_BYTES = 20_160;
    uint256 private constant POINTER_CODE_BYTES = HALF_BYTES + 1;
    uint256 private constant A_ENCODED_BYTES = 16_576;
    uint256 private constant T1_ENCODED_BYTES = 3328;

    uint256 private constant Q = 8_380_417;
    uint256 private constant N = 256;
    uint256 private constant D_FACTOR = 8192;
    uint256 private constant ZETA = 1753;

    uint256 private constant SHAKE128_RATE = 168;
    uint256 private constant XOF_BYTE_LIMIT = 4096;
    bytes32 private constant F1600_CODEHASH =
        0x4afb4435879cdf8e50474c7aab2bc3a679caed432550ad6dba64f509309a817b;

    struct PointerPair {
        address pointer0;
        address pointer1;
    }

    address public immutable f1600Helper;
    mapping(bytes32 rawKeyId => PointerPair pointers) private _registered;

    error BadHelper();
    error BadRawKeyLength();
    error RejectionStreamExhausted();
    error BadPointer();
    error BadDerivation();

    constructor(address helper) {
        if (helper.codehash != F1600_CODEHASH) revert BadHelper();
        f1600Helper = helper;
    }

    /// @notice Derive, store, and return the canonical expanded-key handle.
    /// @param rawPublicKey Exact 1,952-byte FIPS 204 ML-DSA-65 public key.
    /// @return handle Two immutable SSTORE2 pointer addresses packed into 40 bytes.
    function register(bytes calldata rawPublicKey) external returns (bytes memory handle) {
        if (rawPublicKey.length != RAW_KEY_BYTES) revert BadRawKeyLength();
        if (f1600Helper.codehash != F1600_CODEHASH) revert BadHelper();

        bytes32 rawKeyId = keccak256(rawPublicKey);
        PointerPair storage cached = _registered[rawKeyId];
        if (cached.pointer0 != address(0)) {
            if (cached.pointer1 == address(0) || cached.pointer0 == cached.pointer1) revert BadPointer();
            return abi.encodePacked(cached.pointer0, cached.pointer1);
        }

        bytes memory rho = new bytes(32);
        for (uint256 i = 0; i < 32; ++i) rho[i] = rawPublicKey[i];

        uint256[][][] memory aHat = new uint256[][][](6);
        for (uint256 row = 0; row < 6; ++row) {
            aHat[row] = new uint256[][](5);
            for (uint256 column = 0; column < 5; ++column) {
                aHat[row][column] = _sampleAhatPacked(rho, row, column);
            }
        }

        uint256[] memory roots = _nttRoots();
        uint256[][] memory t1Hat = new uint256[][](6);
        for (uint256 row = 0; row < 6; ++row) {
            t1Hat[row] = _decodeNttAndPackT1(rawPublicKey, 32 + row * 320, roots);
        }

        bytes memory rawCopy = rawPublicKey;
        bytes memory tr = shake256Any(rawCopy, 64, f1600Helper);
        if (tr.length != 64) revert BadDerivation();

        bytes memory half0 = _encodeHalf(aHat, t1Hat, tr, 0);
        bytes memory half1 = _encodeHalf(aHat, t1Hat, tr, 3);

        address pointer0 = SSTORE2.write(half0);
        address pointer1 = SSTORE2.write(half1);
        if (
            pointer0 == address(0) || pointer1 == address(0) || pointer0 == pointer1
                || pointer0.code.length != POINTER_CODE_BYTES || pointer1.code.length != POINTER_CODE_BYTES
                || pointer0.codehash != keccak256(abi.encodePacked(bytes1(0), half0))
                || pointer1.codehash != keccak256(abi.encodePacked(bytes1(0), half1))
        ) revert BadPointer();

        _registered[rawKeyId] = PointerPair({pointer0: pointer0, pointer1: pointer1});
        handle = abi.encodePacked(pointer0, pointer1);
        if (handle.length != 40) revert BadDerivation();
    }

    /// @notice Return the registered handle for a raw-key identifier.
    /// @dev Returns empty bytes when no canonical key is registered for the id.
    function lookup(bytes32 rawKeyId) external view returns (bytes memory handle) {
        PointerPair storage pointers = _registered[rawKeyId];
        if (pointers.pointer0 == address(0)) return new bytes(0);
        if (pointers.pointer1 == address(0) || pointers.pointer0 == pointers.pointer1) revert BadPointer();
        return abi.encodePacked(pointers.pointer0, pointers.pointer1);
    }

    function _sampleAhatPacked(bytes memory rho, uint256 row, uint256 column)
        private
        view
        returns (uint256[] memory packed)
    {
        uint256[25] memory state;
        for (uint256 i = 0; i < 32; ++i) _xorStateByte(state, i, uint8(rho[i]));
        _xorStateByte(state, 32, uint8(column));
        _xorStateByte(state, 33, uint8(row));
        _xorStateByte(state, 34, 0x1f);
        _xorStateByte(state, SHAKE128_RATE - 1, 0x80);
        f1600Fast170(state, f1600Helper);

        packed = new uint256[](32);
        uint256 accepted;
        uint256 consumed;

        while (consumed + 3 <= XOF_BYTE_LIMIT) {
            uint256 blockBudget = SHAKE128_RATE;
            uint256 remaining = XOF_BYTE_LIMIT - consumed;
            if (blockBudget > remaining) blockBudget = remaining;
            blockBudget -= blockBudget % 3;

            for (uint256 offset = 0; offset < blockBudget; offset += 3) {
                uint256 candidate = _stateByte(state, offset) | (_stateByte(state, offset + 1) << 8)
                    | (_stateByte(state, offset + 2) << 16);
                candidate &= 0x7fffff;
                consumed += 3;
                if (candidate < Q) {
                    packed[accepted >> 3] |= candidate << ((accepted & 7) * 32);
                    ++accepted;
                    if (accepted == N) return packed;
                }
            }

            if (consumed + 3 > XOF_BYTE_LIMIT) break;
            f1600Fast170(state, f1600Helper);
        }

        revert RejectionStreamExhausted();
    }

    function _decodeNttAndPackT1(bytes calldata rawPublicKey, uint256 offset, uint256[] memory roots)
        private
        pure
        returns (uint256[] memory packed)
    {
        uint256[] memory polynomial = new uint256[](N);
        for (uint256 group = 0; group < 64; ++group) {
            uint256 start = offset + group * 5;
            uint256 bits = uint8(rawPublicKey[start]) | (uint256(uint8(rawPublicKey[start + 1])) << 8)
                | (uint256(uint8(rawPublicKey[start + 2])) << 16)
                | (uint256(uint8(rawPublicKey[start + 3])) << 24)
                | (uint256(uint8(rawPublicKey[start + 4])) << 32);
            uint256 coefficient = group * 4;
            polynomial[coefficient] = mulmod(bits & 0x3ff, D_FACTOR, Q);
            polynomial[coefficient + 1] = mulmod((bits >> 10) & 0x3ff, D_FACTOR, Q);
            polynomial[coefficient + 2] = mulmod((bits >> 20) & 0x3ff, D_FACTOR, Q);
            polynomial[coefficient + 3] = mulmod((bits >> 30) & 0x3ff, D_FACTOR, Q);
        }

        _forwardNtt(polynomial, roots);
        packed = _packPolynomial(polynomial);
    }

    function _forwardNtt(uint256[] memory polynomial, uint256[] memory roots) private pure {
        if (polynomial.length != N || roots.length != N) revert BadDerivation();
        uint256 rootIndex;
        for (uint256 length = 128; length != 0; length >>= 1) {
            for (uint256 start = 0; start < N; start += length * 2) {
                ++rootIndex;
                uint256 root = roots[rootIndex];
                for (uint256 index = start; index < start + length; ++index) {
                    uint256 upper = polynomial[index];
                    uint256 product = mulmod(root, polynomial[index + length], Q);
                    polynomial[index] = addmod(upper, product, Q);
                    polynomial[index + length] = addmod(upper, Q - product, Q);
                }
            }
        }
        if (rootIndex != 255) revert BadDerivation();
    }

    function _nttRoots() private pure returns (uint256[] memory roots) {
        roots = new uint256[](N);
        roots[0] = 1;
        for (uint256 index = 1; index < N; ++index) {
            roots[index] = _modPow(ZETA, _bitReverse8(index));
        }
    }

    function _packPolynomial(uint256[] memory polynomial) private pure returns (uint256[] memory packed) {
        if (polynomial.length != N) revert BadDerivation();
        packed = new uint256[](32);
        for (uint256 index = 0; index < N; ++index) {
            uint256 coefficient = polynomial[index];
            if (coefficient >= Q) revert BadDerivation();
            packed[index >> 3] |= coefficient << ((index & 7) * 32);
        }
    }

    function _encodeHalf(
        uint256[][][] memory aHat,
        uint256[][] memory t1Hat,
        bytes memory tr,
        uint256 firstRow
    ) private pure returns (bytes memory half) {
        uint256[][][] memory aRows = new uint256[][][](3);
        uint256[][] memory t1Rows = new uint256[][](3);
        for (uint256 localRow = 0; localRow < 3; ++localRow) {
            aRows[localRow] = aHat[firstRow + localRow];
            t1Rows[localRow] = t1Hat[firstRow + localRow];
        }

        bytes memory encodedA = abi.encode(aRows);
        bytes memory encodedT1 = abi.encode(t1Rows);
        if (encodedA.length != A_ENCODED_BYTES || encodedT1.length != T1_ENCODED_BYTES || tr.length != 64) {
            revert BadDerivation();
        }
        half = abi.encode(encodedA, tr, encodedT1);
        if (half.length != HALF_BYTES) revert BadDerivation();
    }

    function _xorStateByte(uint256[25] memory state, uint256 index, uint8 value) private pure {
        uint256 lane = index >> 3;
        uint256 shift = (index & 7) * 8;
        state[lane] ^= uint256(value) << shift;
    }

    function _stateByte(uint256[25] memory state, uint256 index) private pure returns (uint256) {
        return (state[index >> 3] >> ((index & 7) * 8)) & 0xff;
    }

    function _bitReverse8(uint256 value) private pure returns (uint256 reversed) {
        for (uint256 bit = 0; bit < 8; ++bit) {
            reversed |= ((value >> bit) & 1) << (7 - bit);
        }
    }

    function _modPow(uint256 base, uint256 exponent) private pure returns (uint256 result) {
        result = 1;
        while (exponent != 0) {
            if ((exponent & 1) != 0) result = mulmod(result, base, Q);
            base = mulmod(base, base, Q);
            exponent >>= 1;
        }
    }
}
