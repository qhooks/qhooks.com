// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {TransientStateLibrary} from "@uniswap/v4-core/src/libraries/TransientStateLibrary.sol";
import {BalanceDelta, BalanceDeltaLibrary} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
import {
    BeforeSwapDelta,
    BeforeSwapDeltaLibrary
} from "@uniswap/v4-core/src/types/BeforeSwapDelta.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

import {QHookBase} from "./QHookBase.sol";

/// @notice Latches a pool-local swap circuit from actual executed input and
///         permits only the fixed controller to resume it after a cooldown.
/// @dev The threshold-reaching swap completes. This is not a stop-loss, oracle,
///      MEV defense, LP-principal guarantee, or guarantee of pool availability.
contract GovernedCircuitRecoveryHook is QHookBase {
    using BalanceDeltaLibrary for BalanceDelta;
    using PoolIdLibrary for PoolKey;
    using TransientStateLibrary for IPoolManager;

    error InvalidController(address controller);
    error InvalidCooldown(uint64 cooldownSeconds);
    error InvalidThresholds(uint128 threshold0For1, uint128 threshold1For0);
    error CallerNotController(address caller);
    error AlreadyInitialized();
    error HookNotInitialized();
    error CircuitIsTripped(
        uint256 generation,
        uint64 trippedAt,
        uint8 tripDirection,
        uint128 tripActualInput
    );
    error UnexpectedSwapDeltas(bool zeroForOne, int128 amount0, int128 amount1);
    error GenerationOverflow();
    error InvalidTripTimestamp(uint256 timestamp);
    error PoolManagerUnlocked();
    error CircuitNotTripped();
    error UnexpectedOldCircuitState(
        uint256 expectedGeneration,
        uint64 expectedTrippedAt,
        uint8 expectedTripDirection,
        uint128 expectedTripActualInput,
        uint128 expectedThreshold0For1,
        uint128 expectedThreshold1For0,
        uint256 actualGeneration,
        uint64 actualTrippedAt,
        uint8 actualTripDirection,
        uint128 actualTripActualInput,
        uint128 actualThreshold0For1,
        uint128 actualThreshold1For0
    );
    error CooldownActive(uint256 availableAt, uint256 currentTime);

    event CircuitTripped(
        bytes32 indexed poolId,
        uint256 indexed generation,
        uint8 indexed tripDirection,
        uint64 trippedAt,
        uint128 tripActualInput,
        uint128 threshold0For1,
        uint128 threshold1For0
    );
    event CircuitResumed(
        bytes32 indexed poolId,
        uint256 indexed generation,
        uint8 indexed tripDirection,
        uint64 trippedAt,
        uint128 tripActualInput,
        uint128 oldThreshold0For1,
        uint128 oldThreshold1For0,
        uint128 newThreshold0For1,
        uint128 newThreshold1For0
    );

    uint160 public constant REQUIRED_FLAGS = Hooks.AFTER_INITIALIZE_FLAG
        | Hooks.BEFORE_SWAP_FLAG | Hooks.AFTER_SWAP_FLAG;

    address public immutable controller;
    uint64 public immutable cooldownSeconds;
    bytes32 public immutable poolId;

    bool public initialized;
    bool public tripped;
    uint256 public generation;
    uint128 public threshold0For1;
    uint128 public threshold1For0;
    uint64 public trippedAt;
    uint8 public tripDirection;
    uint128 public tripActualInput;

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        address controller_,
        uint64 cooldownSeconds_,
        uint128 initialThreshold0For1_,
        uint128 initialThreshold1For0_
    )
        QHookBase(
            manager_,
            currency0_,
            currency1_,
            poolFee_,
            tickSpacing_,
            REQUIRED_FLAGS
        )
    {
        if (controller_ == address(0) || controller_ == address(this)) {
            revert InvalidController(controller_);
        }
        if (cooldownSeconds_ == 0) revert InvalidCooldown(cooldownSeconds_);
        if (initialThreshold0For1_ == 0 || initialThreshold1For0_ == 0) {
            revert InvalidThresholds(
                initialThreshold0For1_, initialThreshold1For0_
            );
        }

        controller = controller_;
        cooldownSeconds = cooldownSeconds_;
        threshold0For1 = initialThreshold0For1_;
        threshold1For0 = initialThreshold1For0_;

        PoolKey memory key = PoolKey({
            currency0: currency0_,
            currency1: currency1_,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(this))
        });
        poolId = PoolId.unwrap(key.toId());
    }

    function afterInitialize(address, PoolKey calldata key, uint160, int24)
        external
        override
        onlyPoolManager(key)
        returns (bytes4)
    {
        if (initialized) revert AlreadyInitialized();
        initialized = true;
        return IHooks.afterInitialize.selector;
    }

    function beforeSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata,
        bytes calldata
    )
        external
        override
        onlyPoolManager(key)
        returns (bytes4, BeforeSwapDelta, uint24)
    {
        if (!initialized) revert HookNotInitialized();
        if (tripped) {
            revert CircuitIsTripped(
                generation, trippedAt, tripDirection, tripActualInput
            );
        }
        return (IHooks.beforeSwap.selector, BeforeSwapDeltaLibrary.ZERO_DELTA, 0);
    }

    function afterSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata params,
        BalanceDelta delta,
        bytes calldata
    ) external override onlyPoolManager(key) returns (bytes4, int128) {
        if (!initialized) revert HookNotInitialized();
        if (tripped) {
            revert CircuitIsTripped(
                generation, trippedAt, tripDirection, tripActualInput
            );
        }

        int128 amount0 = delta.amount0();
        int128 amount1 = delta.amount1();
        if (amount0 == 0 && amount1 == 0) {
            return (IHooks.afterSwap.selector, 0);
        }

        bool zeroForOne = params.zeroForOne;
        uint128 actualInput;
        if (zeroForOne) {
            if (amount0 >= 0 || amount1 < 0) {
                revert UnexpectedSwapDeltas(true, amount0, amount1);
            }
            actualInput = uint128(uint256(-int256(amount0)));
        } else {
            if (amount1 >= 0 || amount0 < 0) {
                revert UnexpectedSwapDeltas(false, amount0, amount1);
            }
            actualInput = uint128(uint256(-int256(amount1)));
        }

        uint128 threshold = zeroForOne ? threshold0For1 : threshold1For0;
        if (actualInput < threshold) {
            return (IHooks.afterSwap.selector, 0);
        }
        if (generation == type(uint256).max) revert GenerationOverflow();
        if (block.timestamp == 0 || block.timestamp > type(uint64).max) {
            revert InvalidTripTimestamp(block.timestamp);
        }

        uint256 nextGeneration = generation + 1;
        uint64 currentTime = uint64(block.timestamp);
        uint8 direction = zeroForOne ? 0 : 1;
        tripped = true;
        generation = nextGeneration;
        trippedAt = currentTime;
        tripDirection = direction;
        tripActualInput = actualInput;

        emit CircuitTripped(
            poolId,
            nextGeneration,
            direction,
            currentTime,
            actualInput,
            threshold0For1,
            threshold1For0
        );
        return (IHooks.afterSwap.selector, 0);
    }

    function resumeCircuit(
        uint256 expectedGeneration,
        uint64 expectedTrippedAt,
        uint8 expectedTripDirection,
        uint128 expectedTripActualInput,
        uint128 expectedOldThreshold0For1,
        uint128 expectedOldThreshold1For0,
        uint128 newThreshold0For1,
        uint128 newThreshold1For0
    ) external {
        if (msg.sender != controller) revert CallerNotController(msg.sender);
        if (!initialized) revert HookNotInitialized();
        if (manager.isUnlocked()) revert PoolManagerUnlocked();
        if (!tripped) revert CircuitNotTripped();

        uint256 actualGeneration = generation;
        uint64 actualTrippedAt = trippedAt;
        uint8 actualTripDirection = tripDirection;
        uint128 actualTripActualInput = tripActualInput;
        uint128 actualThreshold0For1 = threshold0For1;
        uint128 actualThreshold1For0 = threshold1For0;
        if (
            expectedGeneration != actualGeneration
                || expectedTrippedAt != actualTrippedAt
                || expectedTripDirection != actualTripDirection
                || expectedTripActualInput != actualTripActualInput
                || expectedOldThreshold0For1 != actualThreshold0For1
                || expectedOldThreshold1For0 != actualThreshold1For0
        ) {
            revert UnexpectedOldCircuitState(
                expectedGeneration,
                expectedTrippedAt,
                expectedTripDirection,
                expectedTripActualInput,
                expectedOldThreshold0For1,
                expectedOldThreshold1For0,
                actualGeneration,
                actualTrippedAt,
                actualTripDirection,
                actualTripActualInput,
                actualThreshold0For1,
                actualThreshold1For0
            );
        }

        uint256 availableAt =
            uint256(actualTrippedAt) + uint256(cooldownSeconds);
        if (block.timestamp < availableAt) {
            revert CooldownActive(availableAt, block.timestamp);
        }
        if (newThreshold0For1 == 0 || newThreshold1For0 == 0) {
            revert InvalidThresholds(newThreshold0For1, newThreshold1For0);
        }

        tripped = false;
        threshold0For1 = newThreshold0For1;
        threshold1For0 = newThreshold1For0;

        emit CircuitResumed(
            poolId,
            actualGeneration,
            actualTripDirection,
            actualTrippedAt,
            actualTripActualInput,
            actualThreshold0For1,
            actualThreshold1For0,
            newThreshold0For1,
            newThreshold1For0
        );
    }
}
