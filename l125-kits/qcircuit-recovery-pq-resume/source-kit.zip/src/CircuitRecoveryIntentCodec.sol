// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @notice Strict, state-free serialization for resuming one tripped circuit.
/// @dev This library performs no signature, time, nonce, or onchain-state checks.
library CircuitRecoveryIntentCodec {
    uint32 internal constant SCHEMA_VERSION = 1;
    uint8 internal constant ACTION_RESUME_CIRCUIT = 1;
    uint256 internal constant ENCODED_LENGTH = 704;

    bytes32 internal constant MODULE_ID =
        0x51484f4f4b532f43495243554954524553554d452f5631000000000000000000;
    bytes17 internal constant PQ_CONTEXT =
        0x51484f4f4b532f434952435549542f5631;

    bytes32 internal constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 internal constant RECOVERY_TYPEHASH = keccak256(
        "QCircuitRecovery(uint32 schemaVersion,uint256 chainId,address controller,bytes32 moduleId,uint8 actionType,uint64 authEpoch,uint256 nonce,address manager,address hook,bytes32 poolId,uint256 generation,uint64 trippedAt,uint8 tripDirection,uint128 tripActualInput,uint128 oldThreshold0For1,uint128 oldThreshold1For0,uint128 newThreshold0For1,uint128 newThreshold1For0,uint64 cooldownSeconds,uint64 validAfter,uint64 validUntil,bytes32 policyHash)"
    );
    bytes32 internal constant NAME_HASH = keccak256("QHooks");
    bytes32 internal constant VERSION_HASH = keccak256("1");

    struct CircuitRecovery {
        uint32 schemaVersion;
        uint256 chainId;
        address controller;
        bytes32 moduleId;
        uint8 actionType;
        uint64 authEpoch;
        uint256 nonce;
        address manager;
        address hook;
        bytes32 poolId;
        uint256 generation;
        uint64 trippedAt;
        uint8 tripDirection;
        uint128 tripActualInput;
        uint128 oldThreshold0For1;
        uint128 oldThreshold1For0;
        uint128 newThreshold0For1;
        uint128 newThreshold1For0;
        uint64 cooldownSeconds;
        uint64 validAfter;
        uint64 validUntil;
        bytes32 policyHash;
    }

    error InvalidEncodedLength(uint256 actual);
    error NonZeroPadding(uint8 fieldIndex);
    error UnsupportedSchemaVersion(uint32 actual);
    error InvalidChainId();
    error InvalidController();
    error UnsupportedModule(bytes32 actual);
    error UnsupportedAction(uint8 actual);
    error InvalidManager();
    error InvalidHook();
    error TargetsNotDistinct(address controller, address manager, address hook);
    error InvalidPoolId();
    error InvalidGeneration(uint256 generation);
    error InvalidTrippedAt(uint64 trippedAt);
    error InvalidTripDirection(uint8 direction);
    error InvalidTripActualInput(uint128 actualInput, uint128 selectedThreshold);
    error InvalidThresholds(
        uint128 oldThreshold0For1,
        uint128 oldThreshold1For0,
        uint128 newThreshold0For1,
        uint128 newThreshold1For0
    );
    error InvalidCooldown(uint64 cooldownSeconds);
    error InvalidAuthorizationWindow(uint64 validAfter, uint64 validUntil);
    error InvalidPolicyHash();

    function validate(CircuitRecovery memory recovery) internal pure {
        if (recovery.schemaVersion != SCHEMA_VERSION) {
            revert UnsupportedSchemaVersion(recovery.schemaVersion);
        }
        if (recovery.chainId == 0) revert InvalidChainId();
        if (recovery.controller == address(0)) revert InvalidController();
        if (recovery.moduleId != MODULE_ID) revert UnsupportedModule(recovery.moduleId);
        if (recovery.actionType != ACTION_RESUME_CIRCUIT) {
            revert UnsupportedAction(recovery.actionType);
        }
        if (recovery.manager == address(0)) revert InvalidManager();
        if (recovery.hook == address(0)) revert InvalidHook();
        if (
            recovery.controller == recovery.manager
                || recovery.controller == recovery.hook
                || recovery.manager == recovery.hook
        ) {
            revert TargetsNotDistinct(
                recovery.controller, recovery.manager, recovery.hook
            );
        }
        if (recovery.poolId == bytes32(0)) revert InvalidPoolId();
        if (recovery.generation == 0) revert InvalidGeneration(recovery.generation);
        if (recovery.trippedAt == 0) revert InvalidTrippedAt(recovery.trippedAt);
        if (recovery.tripDirection > 1) {
            revert InvalidTripDirection(recovery.tripDirection);
        }
        if (
            recovery.oldThreshold0For1 == 0 || recovery.oldThreshold1For0 == 0
                || recovery.newThreshold0For1 == 0
                || recovery.newThreshold1For0 == 0
        ) {
            revert InvalidThresholds(
                recovery.oldThreshold0For1,
                recovery.oldThreshold1For0,
                recovery.newThreshold0For1,
                recovery.newThreshold1For0
            );
        }
        uint128 selectedThreshold = recovery.tripDirection == 0
            ? recovery.oldThreshold0For1
            : recovery.oldThreshold1For0;
        if (
            recovery.tripActualInput == 0
                || recovery.tripActualInput < selectedThreshold
        ) {
            revert InvalidTripActualInput(
                recovery.tripActualInput, selectedThreshold
            );
        }
        if (recovery.cooldownSeconds == 0) {
            revert InvalidCooldown(recovery.cooldownSeconds);
        }
        if (recovery.validUntil <= recovery.validAfter) {
            revert InvalidAuthorizationWindow(
                recovery.validAfter, recovery.validUntil
            );
        }
        if (recovery.policyHash == bytes32(0)) revert InvalidPolicyHash();
    }

    function encode(CircuitRecovery memory recovery)
        internal
        pure
        returns (bytes memory)
    {
        validate(recovery);
        return _encodeWordsUnchecked(recovery);
    }

    function decode(bytes memory encoded)
        internal
        pure
        returns (CircuitRecovery memory recovery)
    {
        if (encoded.length != ENCODED_LENGTH) {
            revert InvalidEncodedLength(encoded.length);
        }

        _requireFits(encoded, 0, type(uint32).max);
        _requireFits(encoded, 2, type(uint160).max);
        _requireFits(encoded, 4, type(uint8).max);
        _requireFits(encoded, 5, type(uint64).max);
        _requireFits(encoded, 7, type(uint160).max);
        _requireFits(encoded, 8, type(uint160).max);
        _requireFits(encoded, 11, type(uint64).max);
        _requireFits(encoded, 12, type(uint8).max);
        _requireFits(encoded, 13, type(uint128).max);
        _requireFits(encoded, 14, type(uint128).max);
        _requireFits(encoded, 15, type(uint128).max);
        _requireFits(encoded, 16, type(uint128).max);
        _requireFits(encoded, 17, type(uint128).max);
        _requireFits(encoded, 18, type(uint64).max);
        _requireFits(encoded, 19, type(uint64).max);
        _requireFits(encoded, 20, type(uint64).max);

        recovery = abi.decode(encoded, (CircuitRecovery));
        validate(recovery);
    }

    function context() internal pure returns (bytes memory) {
        return abi.encodePacked(PQ_CONTEXT);
    }

    function structHash(CircuitRecovery memory recovery)
        internal
        pure
        returns (bytes32)
    {
        validate(recovery);
        return _structHashUnchecked(recovery);
    }

    function domainSeparator(uint256 chainId, address controller)
        internal
        pure
        returns (bytes32)
    {
        if (chainId == 0) revert InvalidChainId();
        if (controller == address(0)) revert InvalidController();
        return _domainSeparatorUnchecked(chainId, controller);
    }

    function walletDigest(CircuitRecovery memory recovery)
        internal
        pure
        returns (bytes32)
    {
        validate(recovery);
        return keccak256(
            abi.encodePacked(
                hex"1901",
                _domainSeparatorUnchecked(recovery.chainId, recovery.controller),
                _structHashUnchecked(recovery)
            )
        );
    }

    function _encodeWordsUnchecked(CircuitRecovery memory recovery)
        private
        pure
        returns (bytes memory)
    {
        bytes memory fields0Through7 = abi.encode(
            recovery.schemaVersion,
            recovery.chainId,
            recovery.controller,
            recovery.moduleId,
            recovery.actionType,
            recovery.authEpoch,
            recovery.nonce,
            recovery.manager
        );
        bytes memory fields8Through15 = abi.encode(
            recovery.hook,
            recovery.poolId,
            recovery.generation,
            recovery.trippedAt,
            recovery.tripDirection,
            recovery.tripActualInput,
            recovery.oldThreshold0For1,
            recovery.oldThreshold1For0
        );
        bytes memory fields16Through21 = abi.encode(
            recovery.newThreshold0For1,
            recovery.newThreshold1For0,
            recovery.cooldownSeconds,
            recovery.validAfter,
            recovery.validUntil,
            recovery.policyHash
        );
        return bytes.concat(fields0Through7, fields8Through15, fields16Through21);
    }

    function _structHashUnchecked(CircuitRecovery memory recovery)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            bytes.concat(abi.encode(RECOVERY_TYPEHASH), _encodeWordsUnchecked(recovery))
        );
    }

    function _domainSeparatorUnchecked(uint256 chainId, address controller)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            abi.encode(DOMAIN_TYPEHASH, NAME_HASH, VERSION_HASH, chainId, controller)
        );
    }

    function _requireFits(bytes memory encoded, uint8 fieldIndex, uint256 maximum)
        private
        pure
    {
        uint256 word;
        assembly ("memory-safe") {
            word := mload(add(add(encoded, 0x20), mul(fieldIndex, 0x20)))
        }
        if (word > maximum) revert NonZeroPadding(fieldIndex);
    }
}
