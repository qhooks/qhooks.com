// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {CanonicalKeyRegistry} from "./CanonicalKeyRegistry.sol";
import {CircuitRecoveryIntentCodec} from "./CircuitRecoveryIntentCodec.sol";
import {GovernedCircuitRecoveryHook} from "./GovernedCircuitRecoveryHook.sol";
import {ZKNOX_dilithium65} from "../vendor/ethdilithium/ZKNOX_dilithium65.sol";
import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

/// @notice Fixed-purpose wallet-and-ML-DSA controller for one circuit-recovery hook.
/// @dev Local prototype only; enrollment consent, rotation, backup recovery,
///      helper provenance, and production PoolManager identity are out of scope.
contract CircuitRecoveryQController {
    using PoolIdLibrary for PoolKey;

    uint256 private constant RAW_PUBLIC_KEY_LENGTH = 1_952;
    uint256 private constant ML_DSA_SIGNATURE_LENGTH = 3_309;
    uint256 private constant SECP256K1_HALF_ORDER =
        0x7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0;

    bytes4 private constant RAW_VERIFY_SELECTOR =
        bytes4(keccak256("verify(bytes,bytes,bytes,bytes)"));
    bytes32 private constant MODULE_ID =
        0x51484f4f4b532f43495243554954524553554d452f5631000000000000000000;

    address public immutable owner;
    bytes32 public immutable policyHash;
    uint64 public immutable authEpoch;
    uint64 public immutable cooldownSeconds;
    IPoolManager public immutable manager;
    GovernedCircuitRecoveryHook public immutable hook;
    bytes32 public immutable poolId;
    CanonicalKeyRegistry public immutable registry;
    ZKNOX_dilithium65 public immutable verifier;
    bytes32 public immutable rawKeyId;
    address public immutable pointer0;
    address public immutable pointer1;

    uint256 public nextNonce;
    bool private _entered;

    error InvalidConfiguration();
    error InvalidRawKeyLength();
    error InvalidWindow();
    error InvalidNonce();
    error WalletAuthorizationFailed();
    error PQAuthorizationFailed();
    error ReentrantCall();

    event CircuitRecoveryAuthorized(
        bytes32 indexed poolId,
        uint256 indexed nonce,
        bytes32 messageHash,
        bytes32 walletDigest,
        uint64 cooldownSeconds,
        uint256 generation,
        uint64 trippedAt,
        uint8 tripDirection,
        uint128 tripActualInput,
        uint128 oldThreshold0For1,
        uint128 oldThreshold1For0,
        uint128 newThreshold0For1,
        uint128 newThreshold1For0
    );

    constructor(
        address helper,
        IPoolManager manager_,
        address owner_,
        bytes32 policyHash_,
        uint64 authEpoch_,
        bytes memory rawPublicKey,
        address currency0_,
        address currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        uint64 cooldownSeconds_,
        uint128 initialThreshold0For1_,
        uint128 initialThreshold1For0_,
        bytes32 hookSalt
    ) {
        if (rawPublicKey.length != RAW_PUBLIC_KEY_LENGTH) {
            revert InvalidRawKeyLength();
        }

        address self = address(this);
        address managerAddress = address(manager_);
        if (
            managerAddress == address(0) || managerAddress == self
                || managerAddress.code.length == 0 || owner_ == address(0)
                || owner_ == self || owner_.code.length != 0
                || policyHash_ == bytes32(0) || currency0_ == address(0)
                || currency1_ == address(0) || currency0_ >= currency1_
                || currency0_ == self || currency1_ == self
                || currency0_.code.length == 0 || currency1_.code.length == 0
                || cooldownSeconds_ == 0 || initialThreshold0For1_ == 0
                || initialThreshold1For0_ == 0
        ) revert InvalidConfiguration();

        CanonicalKeyRegistry registry_ = new CanonicalKeyRegistry(helper);
        ZKNOX_dilithium65 verifier_ = new ZKNOX_dilithium65(helper);
        bytes memory handle = registry_.register(rawPublicKey);
        if (handle.length != 40) revert InvalidConfiguration();

        address pointer0_;
        address pointer1_;
        assembly ("memory-safe") {
            pointer0_ := shr(96, mload(add(handle, 32)))
            pointer1_ := shr(96, mload(add(handle, 52)))
        }
        if (
            pointer0_ == address(0) || pointer1_ == address(0)
                || pointer0_ == pointer1_
        ) revert InvalidConfiguration();

        bytes32 rawKeyId_ = keccak256(rawPublicKey);
        bytes memory registeredHandle = registry_.lookup(rawKeyId_);
        if (
            registeredHandle.length != 40
                || keccak256(registeredHandle) != keccak256(handle)
                || registry_.f1600Helper() != helper
                || verifier_.f1600Helper() != helper
                || address(registry_) == address(verifier_)
        ) revert InvalidConfiguration();

        Currency currency0 = Currency.wrap(currency0_);
        Currency currency1 = Currency.wrap(currency1_);
        GovernedCircuitRecoveryHook hook_ =
            new GovernedCircuitRecoveryHook{salt: hookSalt}(
                manager_,
                currency0,
                currency1,
                poolFee_,
                tickSpacing_,
                self,
                cooldownSeconds_,
                initialThreshold0For1_,
                initialThreshold1For0_
            );

        PoolKey memory key = PoolKey({
            currency0: currency0,
            currency1: currency1,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(hook_))
        });
        bytes32 poolId_ = PoolId.unwrap(key.toId());
        if (
            address(hook_).code.length == 0 || hook_.controller() != self
                || address(hook_.manager()) != managerAddress
                || Currency.unwrap(hook_.currency0()) != currency0_
                || Currency.unwrap(hook_.currency1()) != currency1_
                || hook_.poolFee() != poolFee_
                || hook_.tickSpacing() != tickSpacing_
                || hook_.cooldownSeconds() != cooldownSeconds_
                || hook_.threshold0For1() != initialThreshold0For1_
                || hook_.threshold1For0() != initialThreshold1For0_
                || hook_.poolId() != poolId_ || hook_.initialized()
                || hook_.tripped() || hook_.generation() != 0
                || hook_.trippedAt() != 0 || hook_.tripDirection() != 0
                || hook_.tripActualInput() != 0
        ) revert InvalidConfiguration();

        owner = owner_;
        policyHash = policyHash_;
        authEpoch = authEpoch_;
        cooldownSeconds = cooldownSeconds_;
        manager = manager_;
        hook = hook_;
        poolId = poolId_;
        registry = registry_;
        verifier = verifier_;
        rawKeyId = rawKeyId_;
        pointer0 = pointer0_;
        pointer1 = pointer1_;
    }

    /// @notice Return the immutable canonical expanded-key pointer pair.
    function keyHandle() public view returns (bytes memory) {
        return abi.encodePacked(pointer0, pointer1);
    }

    /// @notice Resume the bound circuit after wallet and PQ authorization.
    function resumeCircuit(
        uint256 expectedGeneration,
        uint64 expectedTrippedAt,
        uint8 expectedTripDirection,
        uint128 expectedTripActualInput,
        uint128 expectedOldThreshold0For1,
        uint128 expectedOldThreshold1For0,
        uint128 newThreshold0For1,
        uint128 newThreshold1For0,
        uint256 nonce,
        uint64 validAfter,
        uint64 validUntil,
        bytes calldata walletSignature,
        bytes calldata pqSignature
    ) external {
        if (_entered) revert ReentrantCall();
        _entered = true;

        if (
            validUntil <= validAfter || block.timestamp < validAfter
                || block.timestamp >= validUntil
        ) revert InvalidWindow();
        if (nonce != nextNonce) revert InvalidNonce();

        CircuitRecoveryIntentCodec.CircuitRecovery memory recovery =
            CircuitRecoveryIntentCodec.CircuitRecovery({
                schemaVersion: 1,
                chainId: block.chainid,
                controller: address(this),
                moduleId: MODULE_ID,
                actionType: 1,
                authEpoch: authEpoch,
                nonce: nonce,
                manager: address(manager),
                hook: address(hook),
                poolId: poolId,
                generation: expectedGeneration,
                trippedAt: expectedTrippedAt,
                tripDirection: expectedTripDirection,
                tripActualInput: expectedTripActualInput,
                oldThreshold0For1: expectedOldThreshold0For1,
                oldThreshold1For0: expectedOldThreshold1For0,
                newThreshold0For1: newThreshold0For1,
                newThreshold1For0: newThreshold1For0,
                cooldownSeconds: cooldownSeconds,
                validAfter: validAfter,
                validUntil: validUntil,
                policyHash: policyHash
            });

        bytes memory message = CircuitRecoveryIntentCodec.encode(recovery);
        bytes32 walletDigest = CircuitRecoveryIntentCodec.walletDigest(recovery);
        _verifyWallet(walletDigest, walletSignature);
        _verifyPQ(message, pqSignature);

        nextNonce = nonce + 1;
        hook.resumeCircuit(
            expectedGeneration,
            expectedTrippedAt,
            expectedTripDirection,
            expectedTripActualInput,
            expectedOldThreshold0For1,
            expectedOldThreshold1For0,
            newThreshold0For1,
            newThreshold1For0
        );

        _entered = false;
        emit CircuitRecoveryAuthorized(
            poolId,
            nonce,
            keccak256(message),
            walletDigest,
            cooldownSeconds,
            expectedGeneration,
            expectedTrippedAt,
            expectedTripDirection,
            expectedTripActualInput,
            expectedOldThreshold0For1,
            expectedOldThreshold1For0,
            newThreshold0For1,
            newThreshold1For0
        );
    }

    function _verifyWallet(bytes32 digest, bytes calldata signature) private view {
        if (signature.length != 65) revert WalletAuthorizationFailed();

        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly ("memory-safe") {
            r := calldataload(signature.offset)
            s := calldataload(add(signature.offset, 32))
            v := byte(0, calldataload(add(signature.offset, 64)))
        }
        if (
            r == bytes32(0) || s == bytes32(0) || (v != 27 && v != 28)
                || uint256(s) > SECP256K1_HALF_ORDER
        ) revert WalletAuthorizationFailed();

        address recovered = ecrecover(digest, v, r, s);
        if (recovered == address(0) || recovered != owner) {
            revert WalletAuthorizationFailed();
        }
    }

    function _verifyPQ(bytes memory message, bytes calldata signature) private view {
        if (signature.length != ML_DSA_SIGNATURE_LENGTH) {
            revert PQAuthorizationFailed();
        }

        (bool success, bytes memory result) = address(verifier).staticcall(
            abi.encodeWithSelector(
                RAW_VERIFY_SELECTOR,
                keyHandle(),
                message,
                signature,
                CircuitRecoveryIntentCodec.context()
            )
        );
        if (!success || result.length != 32) revert PQAuthorizationFailed();

        uint256 resultWord;
        assembly ("memory-safe") {
            resultWord := mload(add(result, 32))
        }
        if (resultWord != 1) revert PQAuthorizationFailed();
    }
}
