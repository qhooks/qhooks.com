Circuit Recovery | QHooks
=========================

An oversized executed swap completes, then pauses later swaps. Resume after cooldown with dual authorization.

Protected action: Resuming paused swaps after cooldown
Profile: ML-DSA-65

Source integration on local chain 31337. Use a compatible Uniswap v4 PoolManager, ordered ERC-20 currencies and the exact hook permission salt. Wallet and ML-DSA-65 authorization protect only the named action, not the EVM wallet, token transfers or every swap. Key enrollment has a separate, potentially substantial network cost. No automatic public-chain deployment or arbitrary hook combinations.

CONTENTS
- 64 Solidity files, including the configured wrapper and dependencies
- compiler-input.json: complete solc standard JSON input
- project.json: public configuration, requirements and source metadata
- SOURCE-INDEX.json: SHA-256 hashes for every other file in this ZIP
- Original third-party licenses and notices
- helper.json: pinned external helper bytecode and provenance (not built by this source input)

GET STARTED
1. Open https://qhooks.com/circuit-lab.html to configure your project and download a customized source/build package.
2. This starter uses local chain 31337. Repeated-digit addresses are placeholders, not destinations. Volume-window timestamps are fixed examples and must be replaced or matched by a disposable local clock. Raw amounts and sqrt-price bounds are not dollar values.
3. Use solc 0.8.26 with the included input:
   solc --standard-json < compiler-input.json > compiler-output.json
   Check the compiler errors array; a process exit alone does not establish compilation success.
4. Resolve your PoolManager, ordered token pair, fresh owner/key enrollment and exact CREATE2 permission salt. Follow all project.json requirements. Never reuse test keys or treat placeholder owners as onchain enforcement.
5. Exercise your chosen configuration and protected action in an isolated environment before separately reviewing any public-chain deployment. This download neither compiles nor deploys it.

PROFILE AND COST
This family uses ML-DSA-65. It is an optional, more expensive integration path; QGraduation uses the separate hash-based launch profile. Downloading/building does not incur an upfront hook purchase fee. Network costs, enrollment and any applicable trading fees are separate. No wallet connection, payment or transaction is requested by this kit.

REQUIREMENTS
- A single executed swap reaching or exceeding its directional input threshold completes, then latches a pause for later swaps. Thresholds are raw input-token units including fees, not cumulative budgets, dollars, output amounts or requested input.
- The immutable positive cooldown is measured from the actual trip timestamp. Time alone never resumes swaps. Recovery requires wallet AND PQ approval over the complete22-word action, exact old trip and thresholds, and positive replacement thresholds while the manager is locked.
- Both directions pause after either direction trips. Generation and last-trip history are preserved on recovery. Liquidity operations are unaffected. Unavailable signers can leave swaps paused indefinitely.
- No price, oracle, stop-loss, LP-principal, MEV or pool-availability guarantee. Partial fills use actual execution. Pool fee and tick spacing are immutable; a1,000,000pips fee prevents usable exact-output swaps.
- Optional expensive ML-DSA-65 profile, not the cheaper hash-based default. Local chain31337 only. No deployment or network-fee estimate follows compilation.
- Supply a verified manager, pinned helper, EOA owner, nonzero policy hash, authorization epoch and enrolled1952-byte raw public key. Ordered distinct deployed ERC20s only. No private or test keys are included.
- Controller deployment creates its registry, verifier and hook. Find the CREATE2 salt for the actual controller address and full constructor-dependent child initcode with the declared permission flags.
- The helper is an artifact-pinned runtime with its accepted creation envelope, not reproduced from the included Solidity. Preserve notices; packaging does not settle production licensing obligations.
- Compiling a configuration is not its EVM behavior test or independent audit. No wallet/signing/enrollment, key rotation/recovery, automatic deployment, bridging or billing is enabled.

LICENSES
Retain all source headers and bundled notices. Different dependencies have different licenses; this package does not grant rights beyond those licenses or resolve production licensing obligations.
