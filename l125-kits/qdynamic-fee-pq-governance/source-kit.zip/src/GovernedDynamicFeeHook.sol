// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {StateLibrary} from "@uniswap/v4-core/src/libraries/StateLibrary.sol";
import {TransientStateLibrary} from "@uniswap/v4-core/src/libraries/TransientStateLibrary.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

import {QDynamicHookBase} from "./QDynamicHookBase.sol";

/// @notice Stores and applies wallet-and-PQ-governed LP fees for one dynamic-fee pool.
/// @dev This is a pool-local fee policy, not a quote, oracle, MEV, liquidity, or liveness guarantee.
contract GovernedDynamicFeeHook is QDynamicHookBase {
    using PoolIdLibrary for PoolKey;
    using StateLibrary for IPoolManager;
    using TransientStateLibrary for IPoolManager;

    uint24 public constant MAX_GOVERNED_LP_FEE = 100_000;
    uint160 public constant REQUIRED_FLAGS = Hooks.AFTER_INITIALIZE_FLAG;

    address public immutable controller;
    uint24 public immutable initialLpFee;
    uint24 public immutable maxLpFee;
    bytes32 public immutable poolId;

    uint24 public currentLpFee;
    uint256 public version;
    bool public initialized;

    error InvalidController(address controller);
    error InvalidFeePolicy(uint24 initialLpFee, uint24 maxLpFee);
    error CallerNotController(address caller);
    error AlreadyInitialized();
    error HookNotInitialized();
    error PoolManagerUnlocked();
    error UnexpectedOldFee(
        uint256 expectedOldVersion,
        uint24 expectedOldLpFee,
        uint256 actualVersion,
        uint24 actualLpFee
    );
    error InvalidFeeVersion(uint256 currentVersion, uint256 proposedVersion);
    error InvalidLpFee(uint24 proposedLpFee, uint24 maxLpFee);
    error NoOpLpFee(uint24 lpFee);
    error InitialCoreStateMismatch(
        uint160 callbackSqrtPriceX96,
        int24 callbackTick,
        uint160 actualSqrtPriceX96,
        int24 actualTick,
        uint24 actualLpFee
    );
    error CoreStateMismatch(
        uint160 expectedSqrtPriceX96,
        int24 expectedTick,
        uint24 expectedProtocolFee,
        uint24 expectedLpFee,
        uint160 actualSqrtPriceX96,
        int24 actualTick,
        uint24 actualProtocolFee,
        uint24 actualLpFee
    );

    event DynamicLPFeeInitialized(
        bytes32 indexed poolId, uint24 initialLpFee, uint24 maxLpFee
    );
    event DynamicLPFeeReplaced(
        bytes32 indexed poolId,
        uint256 oldVersion,
        uint24 oldLpFee,
        uint256 newVersion,
        uint24 newLpFee,
        uint24 maxLpFee
    );

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        address controller_,
        uint24 initialLpFee_,
        uint24 maxLpFee_
    )
        QDynamicHookBase(
            manager_, currency0_, currency1_, poolFee_, tickSpacing_, REQUIRED_FLAGS
        )
    {
        if (controller_ == address(0) || controller_ == address(this)) {
            revert InvalidController(controller_);
        }
        if (
            maxLpFee_ == 0 || maxLpFee_ > MAX_GOVERNED_LP_FEE
                || initialLpFee_ > maxLpFee_
        ) revert InvalidFeePolicy(initialLpFee_, maxLpFee_);

        controller = controller_;
        initialLpFee = initialLpFee_;
        maxLpFee = maxLpFee_;
        currentLpFee = initialLpFee_;

        PoolKey memory key = PoolKey({
            currency0: currency0_,
            currency1: currency1_,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(this))
        });
        poolId = PoolId.unwrap(key.toId());
    }

    function afterInitialize(
        address,
        PoolKey calldata key,
        uint160 sqrtPriceX96,
        int24 tick
    ) external override onlyPoolManager(key) returns (bytes4) {
        if (initialized) revert AlreadyInitialized();

        PoolId id = PoolId.wrap(poolId);
        (
            uint160 actualSqrtPriceX96,
            int24 actualTick,
            uint24 protocolFee,
            uint24 actualLpFee
        ) = manager.getSlot0(id);
        if (
            actualSqrtPriceX96 == 0 || actualSqrtPriceX96 != sqrtPriceX96
                || actualTick != tick || actualLpFee != 0
        ) {
            revert InitialCoreStateMismatch(
                sqrtPriceX96,
                tick,
                actualSqrtPriceX96,
                actualTick,
                actualLpFee
            );
        }

        manager.updateDynamicLPFee(_poolKey(), initialLpFee);

        (
            uint160 resultingSqrtPriceX96,
            int24 resultingTick,
            uint24 resultingProtocolFee,
            uint24 resultingLpFee
        ) = manager.getSlot0(id);
        if (
            resultingSqrtPriceX96 != actualSqrtPriceX96
                || resultingTick != actualTick || resultingProtocolFee != protocolFee
                || resultingLpFee != initialLpFee
        ) {
            revert CoreStateMismatch(
                actualSqrtPriceX96,
                actualTick,
                protocolFee,
                initialLpFee,
                resultingSqrtPriceX96,
                resultingTick,
                resultingProtocolFee,
                resultingLpFee
            );
        }

        initialized = true;
        emit DynamicLPFeeInitialized(poolId, initialLpFee, maxLpFee);
        return IHooks.afterInitialize.selector;
    }

    function replaceFee(
        uint256 expectedOldVersion,
        uint24 expectedOldLpFee,
        uint256 newVersion,
        uint24 newLpFee
    ) external {
        if (msg.sender != controller) revert CallerNotController(msg.sender);
        if (!initialized) revert HookNotInitialized();
        if (manager.isUnlocked()) revert PoolManagerUnlocked();

        uint256 currentVersion = version;
        uint24 currentFee = currentLpFee;
        if (
            expectedOldVersion != currentVersion || expectedOldLpFee != currentFee
        ) {
            revert UnexpectedOldFee(
                expectedOldVersion,
                expectedOldLpFee,
                currentVersion,
                currentFee
            );
        }
        if (
            currentVersion == type(uint256).max || newVersion != currentVersion + 1
        ) revert InvalidFeeVersion(currentVersion, newVersion);
        if (newLpFee > maxLpFee) revert InvalidLpFee(newLpFee, maxLpFee);
        if (newLpFee == currentFee) revert NoOpLpFee(newLpFee);

        PoolId id = PoolId.wrap(poolId);
        (
            uint160 sqrtPriceX96,
            int24 tick,
            uint24 protocolFee,
            uint24 actualLpFee
        ) = manager.getSlot0(id);
        if (sqrtPriceX96 == 0 || actualLpFee != currentFee) {
            revert CoreStateMismatch(
                sqrtPriceX96,
                tick,
                protocolFee,
                currentFee,
                sqrtPriceX96,
                tick,
                protocolFee,
                actualLpFee
            );
        }

        manager.updateDynamicLPFee(_poolKey(), newLpFee);

        (
            uint160 resultingSqrtPriceX96,
            int24 resultingTick,
            uint24 resultingProtocolFee,
            uint24 resultingLpFee
        ) = manager.getSlot0(id);
        if (
            resultingSqrtPriceX96 != sqrtPriceX96 || resultingTick != tick
                || resultingProtocolFee != protocolFee || resultingLpFee != newLpFee
        ) {
            revert CoreStateMismatch(
                sqrtPriceX96,
                tick,
                protocolFee,
                newLpFee,
                resultingSqrtPriceX96,
                resultingTick,
                resultingProtocolFee,
                resultingLpFee
            );
        }

        version = newVersion;
        currentLpFee = newLpFee;
        emit DynamicLPFeeReplaced(
            poolId,
            currentVersion,
            currentFee,
            newVersion,
            newLpFee,
            maxLpFee
        );
    }

    function _poolKey() private view returns (PoolKey memory) {
        return PoolKey({
            currency0: currency0,
            currency1: currency1,
            fee: poolFee,
            tickSpacing: tickSpacing,
            hooks: IHooks(address(this))
        });
    }
}
