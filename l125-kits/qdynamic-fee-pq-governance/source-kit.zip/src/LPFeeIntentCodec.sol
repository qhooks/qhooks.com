// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @notice Strict, state-free serialization for a governed dynamic LP-fee replacement.
/// @dev This library performs no signature, time, nonce, or onchain-state checks.
library LPFeeIntentCodec {
    uint32 internal constant SCHEMA_VERSION = 1;
    uint8 internal constant ACTION_REPLACE_FEE = 1;
    uint24 internal constant MAX_GOVERNED_LP_FEE = 100_000;
    uint256 internal constant ENCODED_LENGTH = 576;

    bytes32 internal constant MODULE_ID = bytes32("QHOOKS/LPFEEREPLACE/V1");
    bytes15 internal constant PQ_CONTEXT = bytes15("QHOOKS/LPFEE/V1");

    bytes32 internal constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 internal constant REPLACEMENT_TYPEHASH = keccak256(
        "QLPFeeReplacement(uint32 schemaVersion,uint256 chainId,address controller,bytes32 moduleId,uint8 actionType,uint64 authEpoch,uint256 nonce,address manager,address hook,bytes32 poolId,uint256 oldVersion,uint24 oldLpFee,uint256 newVersion,uint24 newLpFee,uint24 maxLpFee,uint64 validAfter,uint64 validUntil,bytes32 policyHash)"
    );
    bytes32 internal constant NAME_HASH = keccak256("QHooks");
    bytes32 internal constant VERSION_HASH = keccak256("1");

    struct FeeReplacement {
        uint32 schemaVersion;
        uint256 chainId;
        address controller;
        bytes32 moduleId;
        uint8 actionType;
        uint64 authEpoch;
        uint256 nonce;
        address manager;
        address hook;
        bytes32 poolId;
        uint256 oldVersion;
        uint24 oldLpFee;
        uint256 newVersion;
        uint24 newLpFee;
        uint24 maxLpFee;
        uint64 validAfter;
        uint64 validUntil;
        bytes32 policyHash;
    }

    error InvalidEncodedLength(uint256 actual);
    error NonZeroPadding(uint8 fieldIndex);
    error UnsupportedSchemaVersion(uint32 actual);
    error InvalidChainId();
    error InvalidController();
    error UnsupportedModule(bytes32 actual);
    error UnsupportedAction(uint8 actual);
    error InvalidManager();
    error InvalidHook();
    error TargetsNotDistinct(address controller, address manager, address hook);
    error InvalidPoolId();
    error InvalidVersion(uint256 oldVersion, uint256 newVersion);
    error InvalidMaximumLpFee(uint24 maxLpFee);
    error LpFeeAboveMaximum(uint24 lpFee, uint24 maxLpFee);
    error NoOpLpFee(uint24 lpFee);
    error InvalidWindow(uint64 validAfter, uint64 validUntil);
    error InvalidPolicyHash();

    function validate(FeeReplacement memory replacement) internal pure {
        if (replacement.schemaVersion != SCHEMA_VERSION) {
            revert UnsupportedSchemaVersion(replacement.schemaVersion);
        }
        if (replacement.chainId == 0) revert InvalidChainId();
        if (replacement.controller == address(0)) revert InvalidController();
        if (replacement.moduleId != MODULE_ID) revert UnsupportedModule(replacement.moduleId);
        if (replacement.actionType != ACTION_REPLACE_FEE) {
            revert UnsupportedAction(replacement.actionType);
        }
        if (replacement.manager == address(0)) revert InvalidManager();
        if (replacement.hook == address(0)) revert InvalidHook();
        if (
            replacement.controller == replacement.manager
                || replacement.controller == replacement.hook
                || replacement.manager == replacement.hook
        ) {
            revert TargetsNotDistinct(
                replacement.controller, replacement.manager, replacement.hook
            );
        }
        if (replacement.poolId == bytes32(0)) revert InvalidPoolId();
        if (
            replacement.oldVersion == type(uint256).max
                || replacement.newVersion != replacement.oldVersion + 1
        ) {
            revert InvalidVersion(replacement.oldVersion, replacement.newVersion);
        }
        if (
            replacement.maxLpFee == 0
                || replacement.maxLpFee > MAX_GOVERNED_LP_FEE
        ) revert InvalidMaximumLpFee(replacement.maxLpFee);
        if (replacement.oldLpFee > replacement.maxLpFee) {
            revert LpFeeAboveMaximum(replacement.oldLpFee, replacement.maxLpFee);
        }
        if (replacement.newLpFee > replacement.maxLpFee) {
            revert LpFeeAboveMaximum(replacement.newLpFee, replacement.maxLpFee);
        }
        if (replacement.newLpFee == replacement.oldLpFee) {
            revert NoOpLpFee(replacement.newLpFee);
        }
        if (replacement.validUntil <= replacement.validAfter) {
            revert InvalidWindow(replacement.validAfter, replacement.validUntil);
        }
        if (replacement.policyHash == bytes32(0)) revert InvalidPolicyHash();
    }

    function encode(FeeReplacement memory replacement) internal pure returns (bytes memory) {
        validate(replacement);
        return _encodeWordsUnchecked(replacement);
    }

    function decode(bytes memory encoded)
        internal
        pure
        returns (FeeReplacement memory replacement)
    {
        if (encoded.length != ENCODED_LENGTH) revert InvalidEncodedLength(encoded.length);

        _requireFits(encoded, 0, type(uint32).max);
        _requireFits(encoded, 2, type(uint160).max);
        _requireFits(encoded, 4, type(uint8).max);
        _requireFits(encoded, 5, type(uint64).max);
        _requireFits(encoded, 7, type(uint160).max);
        _requireFits(encoded, 8, type(uint160).max);
        _requireFits(encoded, 11, type(uint24).max);
        _requireFits(encoded, 13, type(uint24).max);
        _requireFits(encoded, 14, type(uint24).max);
        _requireFits(encoded, 15, type(uint64).max);
        _requireFits(encoded, 16, type(uint64).max);

        replacement = abi.decode(encoded, (FeeReplacement));
        validate(replacement);
    }

    function context() internal pure returns (bytes memory) {
        return abi.encodePacked(PQ_CONTEXT);
    }

    function structHash(FeeReplacement memory replacement) internal pure returns (bytes32) {
        validate(replacement);
        return _structHashUnchecked(replacement);
    }

    function domainSeparator(uint256 chainId, address controller)
        internal
        pure
        returns (bytes32)
    {
        if (chainId == 0) revert InvalidChainId();
        if (controller == address(0)) revert InvalidController();
        return _domainSeparatorUnchecked(chainId, controller);
    }

    function walletDigest(FeeReplacement memory replacement)
        internal
        pure
        returns (bytes32)
    {
        validate(replacement);
        return keccak256(
            abi.encodePacked(
                hex"1901",
                _domainSeparatorUnchecked(replacement.chainId, replacement.controller),
                _structHashUnchecked(replacement)
            )
        );
    }

    function _encodeWordsUnchecked(FeeReplacement memory replacement)
        private
        pure
        returns (bytes memory)
    {
        bytes memory fields0Through5 = abi.encode(
            replacement.schemaVersion,
            replacement.chainId,
            replacement.controller,
            replacement.moduleId,
            replacement.actionType,
            replacement.authEpoch
        );
        bytes memory fields6Through11 = abi.encode(
            replacement.nonce,
            replacement.manager,
            replacement.hook,
            replacement.poolId,
            replacement.oldVersion,
            replacement.oldLpFee
        );
        bytes memory fields12Through17 = abi.encode(
            replacement.newVersion,
            replacement.newLpFee,
            replacement.maxLpFee,
            replacement.validAfter,
            replacement.validUntil,
            replacement.policyHash
        );
        return bytes.concat(fields0Through5, fields6Through11, fields12Through17);
    }

    function _structHashUnchecked(FeeReplacement memory replacement)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            bytes.concat(abi.encode(REPLACEMENT_TYPEHASH), _encodeWordsUnchecked(replacement))
        );
    }

    function _domainSeparatorUnchecked(uint256 chainId, address controller)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            abi.encode(DOMAIN_TYPEHASH, NAME_HASH, VERSION_HASH, chainId, controller)
        );
    }

    function _requireFits(bytes memory encoded, uint8 fieldIndex, uint256 maximum)
        private
        pure
    {
        uint256 word;
        assembly ("memory-safe") {
            word := mload(add(add(encoded, 0x20), mul(fieldIndex, 0x20)))
        }
        if (word > maximum) revert NonZeroPadding(fieldIndex);
    }
}
