// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import { IPoolManager } from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';
import { LPFeeLibrary } from '@uniswap/v4-core/src/libraries/LPFeeLibrary.sol';
import { LPFeeQController } from './LPFeeQController.sol';

contract ConfiguredFeeController is LPFeeQController {
  constructor(
    address helper_,
    IPoolManager manager_,
    address owner_,
    bytes32 policyHash_,
    uint64 authEpoch_,
    bytes memory rawPublicKey_,
    address currency0_,
    address currency1_,
    bytes32 hookSalt_
  ) LPFeeQController(
    helper_,
    manager_,
    owner_,
    policyHash_,
    authEpoch_,
    rawPublicKey_,
    currency0_,
    currency1_,
    LPFeeLibrary.DYNAMIC_FEE_FLAG,
    60,
    3000,
    100000,
    hookSalt_
  ) {
    require(block.chainid == 31337, 'Local chain only');
  }
}