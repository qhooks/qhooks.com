// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {CanonicalKeyRegistry} from "./CanonicalKeyRegistry.sol";
import {DirectionalFeeIntentCodec} from "./DirectionalFeeIntentCodec.sol";
import {GovernedDirectionalFeeHook} from "./GovernedDirectionalFeeHook.sol";
import {ZKNOX_dilithium65} from "../vendor/ethdilithium/ZKNOX_dilithium65.sol";
import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {LPFeeLibrary} from "@uniswap/v4-core/src/libraries/LPFeeLibrary.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

/// @notice Fixed-purpose wallet-and-ML-DSA controller for one directional-fee pool.
/// @dev Local prototype only; enrollment consent, rotation, recovery, and production
///      PoolManager/helper identity selection remain outside this source scope.
contract DirectionalFeeQController {
    using PoolIdLibrary for PoolKey;

    uint256 private constant RAW_PUBLIC_KEY_LENGTH = 1_952;
    uint256 private constant ML_DSA_SIGNATURE_LENGTH = 3_309;
    uint24 private constant MAX_GOVERNED_LP_FEE = 100_000;
    uint160 private constant ALL_HOOK_MASK = uint160((1 << 14) - 1);
    uint256 private constant SECP256K1_HALF_ORDER =
        0x7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0;

    bytes4 private constant RAW_VERIFY_SELECTOR =
        bytes4(keccak256("verify(bytes,bytes,bytes,bytes)"));
    bytes32 private constant MODULE_ID = bytes32("QHOOKS/DIRFEES/V1");

    uint32 public constant MIN_DELAY_SECONDS = 60;
    uint32 public constant MAX_DELAY_SECONDS = 604_800;

    address public immutable owner;
    bytes32 public immutable policyHash;
    uint64 public immutable authEpoch;
    IPoolManager public immutable manager;
    GovernedDirectionalFeeHook public immutable hook;
    bytes32 public immutable poolId;
    CanonicalKeyRegistry public immutable registry;
    ZKNOX_dilithium65 public immutable verifier;
    bytes32 public immutable rawKeyId;
    address public immutable pointer0;
    address public immutable pointer1;
    uint24 public immutable maxLpFee;

    uint256 public nextNonce;
    bool private _entered;

    error InvalidConfiguration();
    error InvalidRawKeyLength();
    error InvalidWindow();
    error InvalidNonce();
    error WalletAuthorizationFailed();
    error PQAuthorizationFailed();
    error ReentrantCall();

    event DirectionalFeeScheduleAuthorized(
        bytes32 indexed poolId,
        uint256 indexed nonce,
        bytes32 messageHash,
        bytes32 walletDigest,
        uint256 oldVersion,
        uint24 oldFee0For1,
        uint24 oldFee1For0,
        uint256 newVersion,
        uint24 newFee0For1,
        uint24 newFee1For0,
        uint64 activateAt,
        uint24 maxLpFee,
        uint32 minDelaySeconds,
        uint32 maxDelaySeconds
    );

    constructor(
        address helper,
        IPoolManager manager_,
        address owner_,
        bytes32 policyHash_,
        uint64 authEpoch_,
        bytes memory rawPublicKey,
        address currency0_,
        address currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        uint24 initialFee0For1_,
        uint24 initialFee1For0_,
        uint24 maxLpFee_,
        bytes32 hookSalt
    ) {
        if (rawPublicKey.length != RAW_PUBLIC_KEY_LENGTH) revert InvalidRawKeyLength();

        address self = address(this);
        address managerAddress = address(manager_);
        if (
            managerAddress == address(0) || managerAddress == self
                || managerAddress.code.length == 0 || owner_ == address(0)
                || owner_ == self || owner_.code.length != 0
                || policyHash_ == bytes32(0) || currency0_ == address(0)
                || currency1_ == address(0) || currency0_ >= currency1_
                || currency0_ == self || currency1_ == self
                || currency0_.code.length == 0 || currency1_.code.length == 0
                || poolFee_ != LPFeeLibrary.DYNAMIC_FEE_FLAG
                || maxLpFee_ == 0 || maxLpFee_ > MAX_GOVERNED_LP_FEE
                || initialFee0For1_ > maxLpFee_ || initialFee1For0_ > maxLpFee_
        ) revert InvalidConfiguration();

        CanonicalKeyRegistry registry_ = new CanonicalKeyRegistry(helper);
        ZKNOX_dilithium65 verifier_ = new ZKNOX_dilithium65(helper);
        bytes memory handle = registry_.register(rawPublicKey);
        if (handle.length != 40) revert InvalidConfiguration();

        address pointer0_;
        address pointer1_;
        assembly ("memory-safe") {
            pointer0_ := shr(96, mload(add(handle, 32)))
            pointer1_ := shr(96, mload(add(handle, 52)))
        }
        if (
            pointer0_ == address(0) || pointer1_ == address(0)
                || pointer0_ == pointer1_
        ) revert InvalidConfiguration();

        bytes32 rawKeyId_ = keccak256(rawPublicKey);
        bytes memory registeredHandle = registry_.lookup(rawKeyId_);
        if (
            registeredHandle.length != 40
                || keccak256(registeredHandle) != keccak256(handle)
                || registry_.f1600Helper() != helper
                || verifier_.f1600Helper() != helper
                || address(registry_) == address(verifier_)
        ) revert InvalidConfiguration();

        Currency currency0 = Currency.wrap(currency0_);
        Currency currency1 = Currency.wrap(currency1_);
        GovernedDirectionalFeeHook hook_ =
            new GovernedDirectionalFeeHook{salt: hookSalt}(
                manager_,
                currency0,
                currency1,
                poolFee_,
                tickSpacing_,
                self,
                initialFee0For1_,
                initialFee1For0_,
                maxLpFee_
            );

        PoolKey memory key = PoolKey({
            currency0: currency0,
            currency1: currency1,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(hook_))
        });
        bytes32 poolId_ = PoolId.unwrap(key.toId());
        if (
            address(hook_).code.length == 0 || hook_.controller() != self
                || address(hook_.manager()) != managerAddress
                || Currency.unwrap(hook_.currency0()) != currency0_
                || Currency.unwrap(hook_.currency1()) != currency1_
                || hook_.poolFee() != LPFeeLibrary.DYNAMIC_FEE_FLAG
                || hook_.poolFee() != poolFee_
                || hook_.tickSpacing() != tickSpacing_ || hook_.poolId() != poolId_
                || hook_.initialFee0For1() != initialFee0For1_
                || hook_.initialFee1For0() != initialFee1For0_
                || hook_.maxLpFee() != maxLpFee_ || hook_.activeVersion() != 0
                || hook_.activeFee0For1() != initialFee0For1_
                || hook_.activeFee1For0() != initialFee1For0_ || hook_.pending()
                || hook_.pendingVersion() != 0 || hook_.pendingFee0For1() != 0
                || hook_.pendingFee1For0() != 0 || hook_.pendingActivateAt() != 0
                || hook_.MIN_DELAY_SECONDS() != MIN_DELAY_SECONDS
                || hook_.MAX_DELAY_SECONDS() != MAX_DELAY_SECONDS
                || (uint160(address(hook_)) & ALL_HOOK_MASK)
                    != Hooks.BEFORE_SWAP_FLAG
        ) revert InvalidConfiguration();

        owner = owner_;
        policyHash = policyHash_;
        authEpoch = authEpoch_;
        manager = manager_;
        hook = hook_;
        poolId = poolId_;
        registry = registry_;
        verifier = verifier_;
        rawKeyId = rawKeyId_;
        pointer0 = pointer0_;
        pointer1 = pointer1_;
        maxLpFee = maxLpFee_;
    }

    /// @notice Return the immutable canonical expanded-key pointer pair.
    function keyHandle() public view returns (bytes memory) {
        return abi.encodePacked(pointer0, pointer1);
    }

    /// @notice Queue a future directional-fee pair after wallet and PQ authorization.
    function scheduleFees(
        uint256 expectedOldVersion,
        uint24 expectedOldFee0For1,
        uint24 expectedOldFee1For0,
        uint256 newVersion,
        uint24 newFee0For1,
        uint24 newFee1For0,
        uint64 activateAt,
        uint256 nonce,
        uint64 validAfter,
        uint64 validUntil,
        bytes calldata walletSignature,
        bytes calldata pqSignature
    ) external {
        if (_entered) revert ReentrantCall();
        _entered = true;

        if (
            validUntil <= validAfter || block.timestamp < validAfter
                || block.timestamp >= validUntil
        ) revert InvalidWindow();
        if (nonce != nextNonce || nonce == type(uint256).max) revert InvalidNonce();

        DirectionalFeeIntentCodec.DirectionalFeeSchedule memory schedule =
            DirectionalFeeIntentCodec.DirectionalFeeSchedule({
                schemaVersion: 1,
                chainId: block.chainid,
                controller: address(this),
                moduleId: MODULE_ID,
                actionType: 1,
                authEpoch: authEpoch,
                nonce: nonce,
                manager: address(manager),
                hook: address(hook),
                poolId: poolId,
                oldVersion: expectedOldVersion,
                oldFee0For1: expectedOldFee0For1,
                oldFee1For0: expectedOldFee1For0,
                newVersion: newVersion,
                newFee0For1: newFee0For1,
                newFee1For0: newFee1For0,
                activateAt: activateAt,
                maxLpFee: maxLpFee,
                minDelaySeconds: MIN_DELAY_SECONDS,
                maxDelaySeconds: MAX_DELAY_SECONDS,
                validAfter: validAfter,
                validUntil: validUntil,
                policyHash: policyHash
            });

        bytes memory message = DirectionalFeeIntentCodec.encode(schedule);
        bytes32 walletDigest = DirectionalFeeIntentCodec.walletDigest(schedule);
        _verifyWallet(walletDigest, walletSignature);
        _verifyPQ(message, pqSignature);

        nextNonce = nonce + 1;
        hook.scheduleFees(
            expectedOldVersion,
            expectedOldFee0For1,
            expectedOldFee1For0,
            newVersion,
            newFee0For1,
            newFee1For0,
            activateAt
        );

        _entered = false;
        emit DirectionalFeeScheduleAuthorized(
            poolId,
            nonce,
            keccak256(message),
            walletDigest,
            expectedOldVersion,
            expectedOldFee0For1,
            expectedOldFee1For0,
            newVersion,
            newFee0For1,
            newFee1For0,
            activateAt,
            maxLpFee,
            MIN_DELAY_SECONDS,
            MAX_DELAY_SECONDS
        );
    }

    function _verifyWallet(bytes32 digest, bytes calldata signature) private view {
        if (signature.length != 65) revert WalletAuthorizationFailed();

        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly ("memory-safe") {
            r := calldataload(signature.offset)
            s := calldataload(add(signature.offset, 32))
            v := byte(0, calldataload(add(signature.offset, 64)))
        }
        if (
            r == bytes32(0) || s == bytes32(0) || (v != 27 && v != 28)
                || uint256(s) > SECP256K1_HALF_ORDER
        ) revert WalletAuthorizationFailed();

        address recovered = ecrecover(digest, v, r, s);
        if (recovered == address(0) || recovered != owner) {
            revert WalletAuthorizationFailed();
        }
    }

    function _verifyPQ(bytes memory message, bytes calldata signature) private view {
        if (signature.length != ML_DSA_SIGNATURE_LENGTH) {
            revert PQAuthorizationFailed();
        }

        (bool success, bytes memory result) = address(verifier).staticcall(
            abi.encodeWithSelector(
                RAW_VERIFY_SELECTOR,
                keyHandle(),
                message,
                signature,
                DirectionalFeeIntentCodec.context()
            )
        );
        if (!success || result.length != 32) revert PQAuthorizationFailed();

        uint256 resultWord;
        assembly ("memory-safe") {
            resultWord := mload(add(result, 32))
        }
        if (resultWord != 1) revert PQAuthorizationFailed();
    }
}
