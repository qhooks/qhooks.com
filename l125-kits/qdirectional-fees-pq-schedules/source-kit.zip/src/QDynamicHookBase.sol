// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {LPFeeLibrary} from "@uniswap/v4-core/src/libraries/LPFeeLibrary.sol";
import {BalanceDelta} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
import {BeforeSwapDelta} from "@uniswap/v4-core/src/types/BeforeSwapDelta.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

/// @notice Immutable binding for one real Uniswap v4 dynamic-fee pool.
/// @dev Inactive callbacks fail closed. Derived hooks override only callbacks
/// whose permission bits are fixed into their deployed address.
abstract contract QDynamicHookBase is IHooks {
    error InvalidManager(address manager);
    error CurrenciesNotOrdered(address currency0, address currency1);
    error InvalidDynamicPoolFee(uint24 fee);
    error InvalidTickSpacing(int24 tickSpacing);
    error HookPermissionBitsMismatch(address hook, uint160 expected, uint160 actual);
    error CallerNotPoolManager(address caller);
    error UnexpectedPoolCurrencies(address currency0, address currency1);
    error UnexpectedPoolFee(uint24 fee);
    error UnexpectedTickSpacing(int24 tickSpacing);
    error UnexpectedHook(address hook);
    error InactiveCallback(bytes4 selector);

    uint160 internal constant ALL_HOOK_MASK = uint160((1 << 14) - 1);
    int24 internal constant MAX_TICK_SPACING = type(int16).max;

    IPoolManager public immutable manager;
    Currency public immutable currency0;
    Currency public immutable currency1;
    uint24 public immutable poolFee;
    int24 public immutable tickSpacing;

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        uint160 flags_
    ) {
        address managerAddress = address(manager_);
        address currency0Address = Currency.unwrap(currency0_);
        address currency1Address = Currency.unwrap(currency1_);

        if (managerAddress == address(0) || managerAddress.code.length == 0) {
            revert InvalidManager(managerAddress);
        }
        if (currency0Address >= currency1Address) {
            revert CurrenciesNotOrdered(currency0Address, currency1Address);
        }
        if (poolFee_ != LPFeeLibrary.DYNAMIC_FEE_FLAG) {
            revert InvalidDynamicPoolFee(poolFee_);
        }
        if (tickSpacing_ <= 0 || tickSpacing_ > MAX_TICK_SPACING) {
            revert InvalidTickSpacing(tickSpacing_);
        }

        uint160 actualFlags = uint160(address(this)) & ALL_HOOK_MASK;
        if ((flags_ & ~ALL_HOOK_MASK) != 0 || actualFlags != flags_) {
            revert HookPermissionBitsMismatch(address(this), flags_, actualFlags);
        }

        manager = manager_;
        currency0 = currency0_;
        currency1 = currency1_;
        poolFee = poolFee_;
        tickSpacing = tickSpacing_;
    }

    modifier onlyPoolManager(PoolKey calldata key) {
        if (msg.sender != address(manager)) revert CallerNotPoolManager(msg.sender);
        _validatePoolKey(key);
        _;
    }

    function _validatePoolKey(PoolKey calldata key) internal view {
        address keyCurrency0 = Currency.unwrap(key.currency0);
        address keyCurrency1 = Currency.unwrap(key.currency1);
        if (
            keyCurrency0 != Currency.unwrap(currency0)
                || keyCurrency1 != Currency.unwrap(currency1)
        ) {
            revert UnexpectedPoolCurrencies(keyCurrency0, keyCurrency1);
        }
        if (key.fee != poolFee) revert UnexpectedPoolFee(key.fee);
        if (key.tickSpacing != tickSpacing) {
            revert UnexpectedTickSpacing(key.tickSpacing);
        }
        if (address(key.hooks) != address(this)) {
            revert UnexpectedHook(address(key.hooks));
        }
    }

    function beforeInitialize(address, PoolKey calldata key, uint160)
        external
        virtual
        override
        onlyPoolManager(key)
        returns (bytes4)
    {
        revert InactiveCallback(msg.sig);
    }

    function afterInitialize(address, PoolKey calldata key, uint160, int24)
        external
        virtual
        override
        onlyPoolManager(key)
        returns (bytes4)
    {
        revert InactiveCallback(msg.sig);
    }

    function beforeAddLiquidity(
        address,
        PoolKey calldata key,
        IPoolManager.ModifyLiquidityParams calldata,
        bytes calldata
    ) external virtual override onlyPoolManager(key) returns (bytes4) {
        revert InactiveCallback(msg.sig);
    }

    function afterAddLiquidity(
        address,
        PoolKey calldata key,
        IPoolManager.ModifyLiquidityParams calldata,
        BalanceDelta,
        BalanceDelta,
        bytes calldata
    ) external virtual override onlyPoolManager(key) returns (bytes4, BalanceDelta) {
        revert InactiveCallback(msg.sig);
    }

    function beforeRemoveLiquidity(
        address,
        PoolKey calldata key,
        IPoolManager.ModifyLiquidityParams calldata,
        bytes calldata
    ) external virtual override onlyPoolManager(key) returns (bytes4) {
        revert InactiveCallback(msg.sig);
    }

    function afterRemoveLiquidity(
        address,
        PoolKey calldata key,
        IPoolManager.ModifyLiquidityParams calldata,
        BalanceDelta,
        BalanceDelta,
        bytes calldata
    ) external virtual override onlyPoolManager(key) returns (bytes4, BalanceDelta) {
        revert InactiveCallback(msg.sig);
    }

    function beforeSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata,
        bytes calldata
    ) external virtual override onlyPoolManager(key) returns (bytes4, BeforeSwapDelta, uint24) {
        revert InactiveCallback(msg.sig);
    }

    function afterSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata,
        BalanceDelta,
        bytes calldata
    ) external virtual override onlyPoolManager(key) returns (bytes4, int128) {
        revert InactiveCallback(msg.sig);
    }

    function beforeDonate(address, PoolKey calldata key, uint256, uint256, bytes calldata)
        external
        virtual
        override
        onlyPoolManager(key)
        returns (bytes4)
    {
        revert InactiveCallback(msg.sig);
    }

    function afterDonate(address, PoolKey calldata key, uint256, uint256, bytes calldata)
        external
        virtual
        override
        onlyPoolManager(key)
        returns (bytes4)
    {
        revert InactiveCallback(msg.sig);
    }
}
