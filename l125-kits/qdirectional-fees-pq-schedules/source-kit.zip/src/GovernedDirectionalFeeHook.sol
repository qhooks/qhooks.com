// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {LPFeeLibrary} from "@uniswap/v4-core/src/libraries/LPFeeLibrary.sol";
import {StateLibrary} from "@uniswap/v4-core/src/libraries/StateLibrary.sol";
import {TransientStateLibrary} from "@uniswap/v4-core/src/libraries/TransientStateLibrary.sol";
import {BeforeSwapDelta} from "@uniswap/v4-core/src/types/BeforeSwapDelta.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

import {QDynamicHookBase} from "./QDynamicHookBase.sol";

/// @notice Applies one delayed, wallet-and-PQ-governed directional LP-fee schedule.
/// @dev Chain time controls activation. This is not an oracle, quote, MEV, or liveness guarantee.
contract GovernedDirectionalFeeHook is QDynamicHookBase {
    using PoolIdLibrary for PoolKey;
    using StateLibrary for IPoolManager;
    using TransientStateLibrary for IPoolManager;

    uint24 public constant MAX_GOVERNED_LP_FEE = 100_000;
    uint32 public constant MIN_DELAY_SECONDS = 60;
    uint32 public constant MAX_DELAY_SECONDS = 604_800;
    uint160 public constant REQUIRED_FLAGS = Hooks.BEFORE_SWAP_FLAG;

    address public immutable controller;
    uint24 public immutable initialFee0For1;
    uint24 public immutable initialFee1For0;
    uint24 public immutable maxLpFee;
    bytes32 public immutable poolId;

    uint256 public activeVersion;
    uint24 public activeFee0For1;
    uint24 public activeFee1For0;
    bool public pending;
    uint256 public pendingVersion;
    uint24 public pendingFee0For1;
    uint24 public pendingFee1For0;
    uint64 public pendingActivateAt;

    error InvalidController(address controller);
    error InvalidFeePolicy(uint24 initialFee0For1, uint24 initialFee1For0, uint24 maxLpFee);
    error CallerNotController(address caller);
    error PoolNotInitialized();
    error UnexpectedCoreLpFee(uint24 actualLpFee);
    error PoolManagerUnlocked();
    error PendingScheduleExists(uint256 version, uint64 activateAt);
    error UnexpectedOldFees(
        uint256 expectedVersion,
        uint24 expectedFee0For1,
        uint24 expectedFee1For0,
        uint256 actualVersion,
        uint24 actualFee0For1,
        uint24 actualFee1For0
    );
    error InvalidFeeVersion(uint256 currentVersion, uint256 proposedVersion);
    error FeeAboveMaximum(uint24 proposedFee, uint24 maxLpFee);
    error NoOpDirectionalFees(uint24 fee0For1, uint24 fee1For0);
    error InvalidActivation(uint64 activateAt, uint256 currentTimestamp);

    event DirectionalFeeScheduleQueued(
        bytes32 indexed poolId,
        uint256 oldVersion,
        uint24 oldFee0For1,
        uint24 oldFee1For0,
        uint256 newVersion,
        uint24 newFee0For1,
        uint24 newFee1For0,
        uint64 activateAt,
        uint24 maxLpFee,
        uint32 minDelaySeconds,
        uint32 maxDelaySeconds
    );
    event DirectionalFeeScheduleActivated(
        bytes32 indexed poolId,
        uint256 version,
        uint24 fee0For1,
        uint24 fee1For0
    );

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        address controller_,
        uint24 initialFee0For1_,
        uint24 initialFee1For0_,
        uint24 maxLpFee_
    )
        QDynamicHookBase(
            manager_, currency0_, currency1_, poolFee_, tickSpacing_, REQUIRED_FLAGS
        )
    {
        if (controller_ == address(0) || controller_ == address(this)) {
            revert InvalidController(controller_);
        }
        if (
            maxLpFee_ == 0 || maxLpFee_ > MAX_GOVERNED_LP_FEE
                || initialFee0For1_ > maxLpFee_ || initialFee1For0_ > maxLpFee_
        ) {
            revert InvalidFeePolicy(initialFee0For1_, initialFee1For0_, maxLpFee_);
        }

        controller = controller_;
        initialFee0For1 = initialFee0For1_;
        initialFee1For0 = initialFee1For0_;
        maxLpFee = maxLpFee_;
        activeFee0For1 = initialFee0For1_;
        activeFee1For0 = initialFee1For0_;

        PoolKey memory key = PoolKey({
            currency0: currency0_,
            currency1: currency1_,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(this))
        });
        poolId = PoolId.unwrap(key.toId());
    }

    function effectiveFees()
        external
        view
        returns (uint256 version, uint24 fee0For1, uint24 fee1For0)
    {
        if (pending && block.timestamp >= pendingActivateAt) {
            return (pendingVersion, pendingFee0For1, pendingFee1For0);
        }
        return (activeVersion, activeFee0For1, activeFee1For0);
    }

    function scheduleFees(
        uint256 expectedOldVersion,
        uint24 expectedOldFee0For1,
        uint24 expectedOldFee1For0,
        uint256 newVersion,
        uint24 newFee0For1,
        uint24 newFee1For0,
        uint64 activateAt
    ) external {
        if (msg.sender != controller) revert CallerNotController(msg.sender);
        if (manager.isUnlocked()) revert PoolManagerUnlocked();
        _requireCoreState();

        _activateIfDue();
        if (pending) revert PendingScheduleExists(pendingVersion, pendingActivateAt);

        uint256 currentVersion = activeVersion;
        uint24 currentFee0For1 = activeFee0For1;
        uint24 currentFee1For0 = activeFee1For0;
        if (
            expectedOldVersion != currentVersion
                || expectedOldFee0For1 != currentFee0For1
                || expectedOldFee1For0 != currentFee1For0
        ) {
            revert UnexpectedOldFees(
                expectedOldVersion,
                expectedOldFee0For1,
                expectedOldFee1For0,
                currentVersion,
                currentFee0For1,
                currentFee1For0
            );
        }
        if (
            currentVersion == type(uint256).max || newVersion != currentVersion + 1
        ) revert InvalidFeeVersion(currentVersion, newVersion);
        if (newFee0For1 > maxLpFee) {
            revert FeeAboveMaximum(newFee0For1, maxLpFee);
        }
        if (newFee1For0 > maxLpFee) {
            revert FeeAboveMaximum(newFee1For0, maxLpFee);
        }
        if (
            newFee0For1 == currentFee0For1 && newFee1For0 == currentFee1For0
        ) revert NoOpDirectionalFees(newFee0For1, newFee1For0);

        uint256 currentTimestamp = block.timestamp;
        if (uint256(activateAt) <= currentTimestamp) {
            revert InvalidActivation(activateAt, currentTimestamp);
        }
        uint256 delay = uint256(activateAt) - currentTimestamp;
        if (delay < MIN_DELAY_SECONDS || delay > MAX_DELAY_SECONDS) {
            revert InvalidActivation(activateAt, currentTimestamp);
        }

        pendingVersion = newVersion;
        pendingFee0For1 = newFee0For1;
        pendingFee1For0 = newFee1For0;
        pendingActivateAt = activateAt;
        pending = true;

        emit DirectionalFeeScheduleQueued(
            poolId,
            currentVersion,
            currentFee0For1,
            currentFee1For0,
            newVersion,
            newFee0For1,
            newFee1For0,
            activateAt,
            maxLpFee,
            MIN_DELAY_SECONDS,
            MAX_DELAY_SECONDS
        );
    }

    function beforeSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata params,
        bytes calldata
    ) external override onlyPoolManager(key) returns (bytes4, BeforeSwapDelta, uint24) {
        _requireCoreState();
        _activateIfDue();

        uint24 selectedFee = params.zeroForOne ? activeFee0For1 : activeFee1For0;
        return (
            IHooks.beforeSwap.selector,
            BeforeSwapDelta.wrap(0),
            selectedFee | LPFeeLibrary.OVERRIDE_FEE_FLAG
        );
    }

    function _activateIfDue() private {
        if (!pending || block.timestamp < pendingActivateAt) return;

        uint256 version = pendingVersion;
        uint24 fee0For1 = pendingFee0For1;
        uint24 fee1For0 = pendingFee1For0;

        activeVersion = version;
        activeFee0For1 = fee0For1;
        activeFee1For0 = fee1For0;
        pendingVersion = 0;
        pendingFee0For1 = 0;
        pendingFee1For0 = 0;
        pendingActivateAt = 0;
        pending = false;

        emit DirectionalFeeScheduleActivated(poolId, version, fee0For1, fee1For0);
    }

    function _requireCoreState() private view {
        (uint160 sqrtPriceX96,,, uint24 actualLpFee) =
            manager.getSlot0(PoolId.wrap(poolId));
        if (sqrtPriceX96 == 0) revert PoolNotInitialized();
        if (actualLpFee != 0) revert UnexpectedCoreLpFee(actualLpFee);
    }
}
