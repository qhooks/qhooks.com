// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @notice Strict, state-free serialization for one delayed directional-fee schedule.
/// @dev This library performs no signature, clock, nonce, or onchain-state checks.
library DirectionalFeeIntentCodec {
    uint32 internal constant SCHEMA_VERSION = 1;
    uint8 internal constant ACTION_SCHEDULE_FEES = 1;
    uint24 internal constant MAX_GOVERNED_LP_FEE = 100_000;
    uint32 internal constant MIN_DELAY_SECONDS = 60;
    uint32 internal constant MAX_DELAY_SECONDS = 604_800;
    uint256 internal constant ENCODED_LENGTH = 736;

    bytes32 internal constant MODULE_ID = bytes32("QHOOKS/DIRFEES/V1");
    bytes16 internal constant PQ_CONTEXT = bytes16("QHOOKS/DIRFEE/V1");

    bytes32 internal constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 internal constant SCHEDULE_TYPEHASH = keccak256(
        "QDirectionalFeeSchedule(uint32 schemaVersion,uint256 chainId,address controller,bytes32 moduleId,uint8 actionType,uint64 authEpoch,uint256 nonce,address manager,address hook,bytes32 poolId,uint256 oldVersion,uint24 oldFee0For1,uint24 oldFee1For0,uint256 newVersion,uint24 newFee0For1,uint24 newFee1For0,uint64 activateAt,uint24 maxLpFee,uint32 minDelaySeconds,uint32 maxDelaySeconds,uint64 validAfter,uint64 validUntil,bytes32 policyHash)"
    );
    bytes32 internal constant NAME_HASH = keccak256("QHooks");
    bytes32 internal constant VERSION_HASH = keccak256("1");

    struct DirectionalFeeSchedule {
        uint32 schemaVersion;
        uint256 chainId;
        address controller;
        bytes32 moduleId;
        uint8 actionType;
        uint64 authEpoch;
        uint256 nonce;
        address manager;
        address hook;
        bytes32 poolId;
        uint256 oldVersion;
        uint24 oldFee0For1;
        uint24 oldFee1For0;
        uint256 newVersion;
        uint24 newFee0For1;
        uint24 newFee1For0;
        uint64 activateAt;
        uint24 maxLpFee;
        uint32 minDelaySeconds;
        uint32 maxDelaySeconds;
        uint64 validAfter;
        uint64 validUntil;
        bytes32 policyHash;
    }

    error InvalidEncodedLength(uint256 actual);
    error NonZeroPadding(uint8 fieldIndex);
    error UnsupportedSchemaVersion(uint32 actual);
    error InvalidChainId();
    error InvalidController();
    error UnsupportedModule(bytes32 actual);
    error UnsupportedAction(uint8 actual);
    error InvalidManager();
    error InvalidHook();
    error TargetsNotDistinct(address controller, address manager, address hook);
    error InvalidPoolId();
    error InvalidVersion(uint256 oldVersion, uint256 newVersion);
    error InvalidActivationTime(uint64 activateAt);
    error InvalidDelayPolicy(uint32 minDelaySeconds, uint32 maxDelaySeconds);
    error InvalidMaximumLpFee(uint24 maxLpFee);
    error LpFeeAboveMaximum(uint24 lpFee, uint24 maxLpFee);
    error NoOpDirectionalFees(uint24 fee0For1, uint24 fee1For0);
    error InvalidWindow(uint64 validAfter, uint64 validUntil);
    error InvalidPolicyHash();

    function validate(DirectionalFeeSchedule memory schedule) internal pure {
        if (schedule.schemaVersion != SCHEMA_VERSION) {
            revert UnsupportedSchemaVersion(schedule.schemaVersion);
        }
        if (schedule.chainId == 0) revert InvalidChainId();
        if (schedule.controller == address(0)) revert InvalidController();
        if (schedule.moduleId != MODULE_ID) revert UnsupportedModule(schedule.moduleId);
        if (schedule.actionType != ACTION_SCHEDULE_FEES) {
            revert UnsupportedAction(schedule.actionType);
        }
        if (schedule.manager == address(0)) revert InvalidManager();
        if (schedule.hook == address(0)) revert InvalidHook();
        if (
            schedule.controller == schedule.manager
                || schedule.controller == schedule.hook
                || schedule.manager == schedule.hook
        ) {
            revert TargetsNotDistinct(schedule.controller, schedule.manager, schedule.hook);
        }
        if (schedule.poolId == bytes32(0)) revert InvalidPoolId();
        if (
            schedule.oldVersion == type(uint256).max
                || schedule.newVersion != schedule.oldVersion + 1
        ) revert InvalidVersion(schedule.oldVersion, schedule.newVersion);
        if (schedule.activateAt == 0) revert InvalidActivationTime(schedule.activateAt);
        if (
            schedule.minDelaySeconds != MIN_DELAY_SECONDS
                || schedule.maxDelaySeconds != MAX_DELAY_SECONDS
        ) {
            revert InvalidDelayPolicy(
                schedule.minDelaySeconds, schedule.maxDelaySeconds
            );
        }
        if (
            schedule.maxLpFee == 0
                || schedule.maxLpFee > MAX_GOVERNED_LP_FEE
        ) revert InvalidMaximumLpFee(schedule.maxLpFee);
        _requireFeeBound(schedule.oldFee0For1, schedule.maxLpFee);
        _requireFeeBound(schedule.oldFee1For0, schedule.maxLpFee);
        _requireFeeBound(schedule.newFee0For1, schedule.maxLpFee);
        _requireFeeBound(schedule.newFee1For0, schedule.maxLpFee);
        if (
            schedule.newFee0For1 == schedule.oldFee0For1
                && schedule.newFee1For0 == schedule.oldFee1For0
        ) {
            revert NoOpDirectionalFees(schedule.newFee0For1, schedule.newFee1For0);
        }
        if (schedule.validUntil <= schedule.validAfter) {
            revert InvalidWindow(schedule.validAfter, schedule.validUntil);
        }
        if (schedule.policyHash == bytes32(0)) revert InvalidPolicyHash();
    }

    function encode(DirectionalFeeSchedule memory schedule)
        internal
        pure
        returns (bytes memory)
    {
        validate(schedule);
        return _encodeWordsUnchecked(schedule);
    }

    function decode(bytes memory encoded)
        internal
        pure
        returns (DirectionalFeeSchedule memory schedule)
    {
        if (encoded.length != ENCODED_LENGTH) revert InvalidEncodedLength(encoded.length);

        _requireFits(encoded, 0, type(uint32).max);
        _requireFits(encoded, 2, type(uint160).max);
        _requireFits(encoded, 4, type(uint8).max);
        _requireFits(encoded, 5, type(uint64).max);
        _requireFits(encoded, 7, type(uint160).max);
        _requireFits(encoded, 8, type(uint160).max);
        _requireFits(encoded, 11, type(uint24).max);
        _requireFits(encoded, 12, type(uint24).max);
        _requireFits(encoded, 14, type(uint24).max);
        _requireFits(encoded, 15, type(uint24).max);
        _requireFits(encoded, 16, type(uint64).max);
        _requireFits(encoded, 17, type(uint24).max);
        _requireFits(encoded, 18, type(uint32).max);
        _requireFits(encoded, 19, type(uint32).max);
        _requireFits(encoded, 20, type(uint64).max);
        _requireFits(encoded, 21, type(uint64).max);

        schedule = abi.decode(encoded, (DirectionalFeeSchedule));
        validate(schedule);
    }

    function context() internal pure returns (bytes memory) {
        return abi.encodePacked(PQ_CONTEXT);
    }

    function structHash(DirectionalFeeSchedule memory schedule)
        internal
        pure
        returns (bytes32)
    {
        validate(schedule);
        return _structHashUnchecked(schedule);
    }

    function domainSeparator(uint256 chainId, address controller)
        internal
        pure
        returns (bytes32)
    {
        if (chainId == 0) revert InvalidChainId();
        if (controller == address(0)) revert InvalidController();
        return _domainSeparatorUnchecked(chainId, controller);
    }

    function walletDigest(DirectionalFeeSchedule memory schedule)
        internal
        pure
        returns (bytes32)
    {
        validate(schedule);
        return keccak256(
            abi.encodePacked(
                hex"1901",
                _domainSeparatorUnchecked(schedule.chainId, schedule.controller),
                _structHashUnchecked(schedule)
            )
        );
    }

    function _encodeWordsUnchecked(DirectionalFeeSchedule memory schedule)
        private
        pure
        returns (bytes memory)
    {
        bytes memory fields0Through5 = abi.encode(
            schedule.schemaVersion,
            schedule.chainId,
            schedule.controller,
            schedule.moduleId,
            schedule.actionType,
            schedule.authEpoch
        );
        bytes memory fields6Through11 = abi.encode(
            schedule.nonce,
            schedule.manager,
            schedule.hook,
            schedule.poolId,
            schedule.oldVersion,
            schedule.oldFee0For1
        );
        bytes memory fields12Through17 = abi.encode(
            schedule.oldFee1For0,
            schedule.newVersion,
            schedule.newFee0For1,
            schedule.newFee1For0,
            schedule.activateAt,
            schedule.maxLpFee
        );
        bytes memory fields18Through22 = abi.encode(
            schedule.minDelaySeconds,
            schedule.maxDelaySeconds,
            schedule.validAfter,
            schedule.validUntil,
            schedule.policyHash
        );
        return bytes.concat(
            fields0Through5, fields6Through11, fields12Through17, fields18Through22
        );
    }

    function _structHashUnchecked(DirectionalFeeSchedule memory schedule)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            bytes.concat(abi.encode(SCHEDULE_TYPEHASH), _encodeWordsUnchecked(schedule))
        );
    }

    function _domainSeparatorUnchecked(uint256 chainId, address controller)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            abi.encode(DOMAIN_TYPEHASH, NAME_HASH, VERSION_HASH, chainId, controller)
        );
    }

    function _requireFeeBound(uint24 fee, uint24 maximum) private pure {
        if (fee > maximum) revert LpFeeAboveMaximum(fee, maximum);
    }

    function _requireFits(bytes memory encoded, uint8 fieldIndex, uint256 maximum)
        private
        pure
    {
        uint256 word;
        assembly ("memory-safe") {
            word := mload(add(add(encoded, 0x20), mul(fieldIndex, 0x20)))
        }
        if (word > maximum) revert NonZeroPadding(fieldIndex);
    }
}
