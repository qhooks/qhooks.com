// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {IHooks} from "@uniswap/v4-core/src/interfaces/IHooks.sol";
import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
import {Hooks} from "@uniswap/v4-core/src/libraries/Hooks.sol";
import {StateLibrary} from "@uniswap/v4-core/src/libraries/StateLibrary.sol";
import {TickMath} from "@uniswap/v4-core/src/libraries/TickMath.sol";
import {TransientStateLibrary} from "@uniswap/v4-core/src/libraries/TransientStateLibrary.sol";
import {BalanceDelta} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
import {PoolId, PoolIdLibrary} from "@uniswap/v4-core/src/types/PoolId.sol";
import {PoolKey} from "@uniswap/v4-core/src/types/PoolKey.sol";

import {QHookBase} from "./QHookBase.sol";

/// @notice Enforces a versioned, controller-governed pool-local sqrt-price band.
/// @dev Bounds are spot-price policy only: no oracle, stable-value, MEV, or LP-loss guarantee.
contract GovernedPriceBandHook is QHookBase {
    using PoolIdLibrary for PoolKey;
    using StateLibrary for IPoolManager;
    using TransientStateLibrary for IPoolManager;

    error InvalidController(address controller);
    error InvalidPriceBand(uint160 minSqrtPriceX96, uint160 maxSqrtPriceX96);
    error CallerNotController(address caller);
    error AlreadyInitialized();
    error HookNotInitialized();
    error InitialPriceOutOfBand(
        uint160 actualSqrtPriceX96,
        uint160 minSqrtPriceX96,
        uint160 maxSqrtPriceX96
    );
    error FinalPriceOutOfBand(
        uint160 actualSqrtPriceX96,
        uint160 minSqrtPriceX96,
        uint160 maxSqrtPriceX96
    );
    error PoolManagerUnlocked();
    error UnexpectedOldBand(
        uint256 expectedVersion,
        uint160 expectedMinSqrtPriceX96,
        uint160 expectedMaxSqrtPriceX96,
        uint256 actualVersion,
        uint160 actualMinSqrtPriceX96,
        uint160 actualMaxSqrtPriceX96
    );
    error InvalidBandVersion(uint256 currentVersion, uint256 proposedVersion);
    error CurrentPriceExcluded(
        uint160 actualSqrtPriceX96,
        uint160 proposedMinSqrtPriceX96,
        uint160 proposedMaxSqrtPriceX96
    );

    uint160 public constant REQUIRED_FLAGS =
        Hooks.AFTER_INITIALIZE_FLAG | Hooks.AFTER_SWAP_FLAG;

    address public immutable controller;
    bytes32 public immutable poolId;

    uint160 public minSqrtPriceX96;
    uint160 public maxSqrtPriceX96;
    uint256 public version;
    bool public initialized;

    event PriceBandReplaced(
        bytes32 indexed poolId,
        uint256 oldVersion,
        uint160 oldMinSqrtPriceX96,
        uint160 oldMaxSqrtPriceX96,
        uint256 newVersion,
        uint160 newMinSqrtPriceX96,
        uint160 newMaxSqrtPriceX96
    );

    constructor(
        IPoolManager manager_,
        Currency currency0_,
        Currency currency1_,
        uint24 poolFee_,
        int24 tickSpacing_,
        address controller_,
        uint160 initialMinSqrtPriceX96_,
        uint160 initialMaxSqrtPriceX96_
    )
        QHookBase(
            manager_,
            currency0_,
            currency1_,
            poolFee_,
            tickSpacing_,
            REQUIRED_FLAGS
        )
    {
        if (controller_ == address(0) || controller_ == address(this)) {
            revert InvalidController(controller_);
        }
        if (!_validBand(initialMinSqrtPriceX96_, initialMaxSqrtPriceX96_)) {
            revert InvalidPriceBand(initialMinSqrtPriceX96_, initialMaxSqrtPriceX96_);
        }

        controller = controller_;
        minSqrtPriceX96 = initialMinSqrtPriceX96_;
        maxSqrtPriceX96 = initialMaxSqrtPriceX96_;

        PoolKey memory key = PoolKey({
            currency0: currency0_,
            currency1: currency1_,
            fee: poolFee_,
            tickSpacing: tickSpacing_,
            hooks: IHooks(address(this))
        });
        poolId = PoolId.unwrap(key.toId());
    }

    function afterInitialize(
        address,
        PoolKey calldata key,
        uint160 sqrtPriceX96,
        int24
    ) external override onlyPoolManager(key) returns (bytes4) {
        if (initialized) revert AlreadyInitialized();
        if (sqrtPriceX96 < minSqrtPriceX96 || sqrtPriceX96 > maxSqrtPriceX96) {
            revert InitialPriceOutOfBand(
                sqrtPriceX96, minSqrtPriceX96, maxSqrtPriceX96
            );
        }
        initialized = true;
        return IHooks.afterInitialize.selector;
    }

    function afterSwap(
        address,
        PoolKey calldata key,
        IPoolManager.SwapParams calldata,
        BalanceDelta,
        bytes calldata
    ) external override onlyPoolManager(key) returns (bytes4, int128) {
        if (!initialized) revert HookNotInitialized();
        (uint160 sqrtPriceX96,,,) = manager.getSlot0(PoolId.wrap(poolId));
        if (sqrtPriceX96 < minSqrtPriceX96 || sqrtPriceX96 > maxSqrtPriceX96) {
            revert FinalPriceOutOfBand(
                sqrtPriceX96, minSqrtPriceX96, maxSqrtPriceX96
            );
        }
        return (IHooks.afterSwap.selector, 0);
    }

    function replaceBand(
        uint256 expectedOldVersion,
        uint160 expectedOldMinSqrtPriceX96,
        uint160 expectedOldMaxSqrtPriceX96,
        uint256 newVersion,
        uint160 newMinSqrtPriceX96,
        uint160 newMaxSqrtPriceX96
    ) external {
        if (msg.sender != controller) revert CallerNotController(msg.sender);
        if (!initialized) revert HookNotInitialized();
        if (manager.isUnlocked()) revert PoolManagerUnlocked();

        uint256 currentVersion = version;
        uint160 currentMinSqrtPriceX96 = minSqrtPriceX96;
        uint160 currentMaxSqrtPriceX96 = maxSqrtPriceX96;
        if (
            expectedOldVersion != currentVersion
                || expectedOldMinSqrtPriceX96 != currentMinSqrtPriceX96
                || expectedOldMaxSqrtPriceX96 != currentMaxSqrtPriceX96
        ) {
            revert UnexpectedOldBand(
                expectedOldVersion,
                expectedOldMinSqrtPriceX96,
                expectedOldMaxSqrtPriceX96,
                currentVersion,
                currentMinSqrtPriceX96,
                currentMaxSqrtPriceX96
            );
        }
        if (
            currentVersion == type(uint256).max || newVersion != currentVersion + 1
        ) {
            revert InvalidBandVersion(currentVersion, newVersion);
        }
        if (!_validBand(newMinSqrtPriceX96, newMaxSqrtPriceX96)) {
            revert InvalidPriceBand(newMinSqrtPriceX96, newMaxSqrtPriceX96);
        }

        (uint160 sqrtPriceX96,,,) = manager.getSlot0(PoolId.wrap(poolId));
        if (sqrtPriceX96 < newMinSqrtPriceX96 || sqrtPriceX96 > newMaxSqrtPriceX96) {
            revert CurrentPriceExcluded(
                sqrtPriceX96, newMinSqrtPriceX96, newMaxSqrtPriceX96
            );
        }

        version = newVersion;
        minSqrtPriceX96 = newMinSqrtPriceX96;
        maxSqrtPriceX96 = newMaxSqrtPriceX96;

        emit PriceBandReplaced(
            poolId,
            currentVersion,
            currentMinSqrtPriceX96,
            currentMaxSqrtPriceX96,
            newVersion,
            newMinSqrtPriceX96,
            newMaxSqrtPriceX96
        );
    }

    function _validBand(uint160 minSqrtPriceX96_, uint160 maxSqrtPriceX96_)
        private
        pure
        returns (bool)
    {
        return minSqrtPriceX96_ >= TickMath.MIN_SQRT_PRICE
            && minSqrtPriceX96_ < maxSqrtPriceX96_
            && maxSqrtPriceX96_ < TickMath.MAX_SQRT_PRICE;
    }
}
