// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {TickMath} from "@uniswap/v4-core/src/libraries/TickMath.sol";

/// @notice Strict, state-free serialization for a governed price-band replacement.
/// @dev This library performs no signature, time, nonce, or onchain-state checks.
library PriceBandIntentCodec {
    uint32 internal constant SCHEMA_VERSION = 1;
    uint8 internal constant ACTION_REPLACE_BAND = 1;
    uint256 internal constant ENCODED_LENGTH = 608;

    bytes32 internal constant MODULE_ID =
        0x51484f4f4b532f505249434542414e442f563100000000000000000000000000;
    bytes14 internal constant PQ_CONTEXT = 0x51484f4f4b532f42414e442f5631;

    bytes32 internal constant DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 internal constant REPLACEMENT_TYPEHASH = keccak256(
        "QPriceBandReplacement(uint32 schemaVersion,uint256 chainId,address controller,bytes32 moduleId,uint8 actionType,uint64 authEpoch,uint256 nonce,address manager,address hook,bytes32 poolId,uint256 oldVersion,uint160 oldMinSqrtPriceX96,uint160 oldMaxSqrtPriceX96,uint256 newVersion,uint160 newMinSqrtPriceX96,uint160 newMaxSqrtPriceX96,uint64 validAfter,uint64 validUntil,bytes32 policyHash)"
    );
    bytes32 internal constant NAME_HASH = keccak256("QHooks");
    bytes32 internal constant VERSION_HASH = keccak256("1");

    struct BandReplacement {
        uint32 schemaVersion;
        uint256 chainId;
        address controller;
        bytes32 moduleId;
        uint8 actionType;
        uint64 authEpoch;
        uint256 nonce;
        address manager;
        address hook;
        bytes32 poolId;
        uint256 oldVersion;
        uint160 oldMinSqrtPriceX96;
        uint160 oldMaxSqrtPriceX96;
        uint256 newVersion;
        uint160 newMinSqrtPriceX96;
        uint160 newMaxSqrtPriceX96;
        uint64 validAfter;
        uint64 validUntil;
        bytes32 policyHash;
    }

    error InvalidEncodedLength(uint256 actual);
    error NonZeroPadding(uint8 fieldIndex);
    error UnsupportedSchemaVersion(uint32 actual);
    error InvalidChainId();
    error InvalidController();
    error UnsupportedModule(bytes32 actual);
    error UnsupportedAction(uint8 actual);
    error InvalidManager();
    error InvalidHook();
    error TargetsNotDistinct(address controller, address manager, address hook);
    error InvalidPoolId();
    error InvalidOldPriceBand(uint160 minSqrtPriceX96, uint160 maxSqrtPriceX96);
    error InvalidNewPriceBand(uint160 minSqrtPriceX96, uint160 maxSqrtPriceX96);
    error InvalidVersion(uint256 oldVersion, uint256 newVersion);
    error InvalidWindow(uint64 validAfter, uint64 validUntil);
    error InvalidPolicyHash();

    function validate(BandReplacement memory replacement) internal pure {
        if (replacement.schemaVersion != SCHEMA_VERSION) {
            revert UnsupportedSchemaVersion(replacement.schemaVersion);
        }
        if (replacement.chainId == 0) revert InvalidChainId();
        if (replacement.controller == address(0)) revert InvalidController();
        if (replacement.moduleId != MODULE_ID) revert UnsupportedModule(replacement.moduleId);
        if (replacement.actionType != ACTION_REPLACE_BAND) {
            revert UnsupportedAction(replacement.actionType);
        }
        if (replacement.manager == address(0)) revert InvalidManager();
        if (replacement.hook == address(0)) revert InvalidHook();
        if (
            replacement.controller == replacement.manager
                || replacement.controller == replacement.hook
                || replacement.manager == replacement.hook
        ) {
            revert TargetsNotDistinct(
                replacement.controller, replacement.manager, replacement.hook
            );
        }
        if (replacement.poolId == bytes32(0)) revert InvalidPoolId();
        if (!_validBand(replacement.oldMinSqrtPriceX96, replacement.oldMaxSqrtPriceX96)) {
            revert InvalidOldPriceBand(
                replacement.oldMinSqrtPriceX96, replacement.oldMaxSqrtPriceX96
            );
        }
        if (!_validBand(replacement.newMinSqrtPriceX96, replacement.newMaxSqrtPriceX96)) {
            revert InvalidNewPriceBand(
                replacement.newMinSqrtPriceX96, replacement.newMaxSqrtPriceX96
            );
        }
        if (
            replacement.oldVersion == type(uint256).max
                || replacement.newVersion != replacement.oldVersion + 1
        ) {
            revert InvalidVersion(replacement.oldVersion, replacement.newVersion);
        }
        if (replacement.validUntil <= replacement.validAfter) {
            revert InvalidWindow(replacement.validAfter, replacement.validUntil);
        }
        if (replacement.policyHash == bytes32(0)) revert InvalidPolicyHash();
    }

    function encode(BandReplacement memory replacement) internal pure returns (bytes memory) {
        validate(replacement);
        return abi.encode(
            replacement.schemaVersion,
            replacement.chainId,
            replacement.controller,
            replacement.moduleId,
            replacement.actionType,
            replacement.authEpoch,
            replacement.nonce,
            replacement.manager,
            replacement.hook,
            replacement.poolId,
            replacement.oldVersion,
            replacement.oldMinSqrtPriceX96,
            replacement.oldMaxSqrtPriceX96,
            replacement.newVersion,
            replacement.newMinSqrtPriceX96,
            replacement.newMaxSqrtPriceX96,
            replacement.validAfter,
            replacement.validUntil,
            replacement.policyHash
        );
    }

    function decode(bytes memory encoded)
        internal
        pure
        returns (BandReplacement memory replacement)
    {
        if (encoded.length != ENCODED_LENGTH) revert InvalidEncodedLength(encoded.length);

        _requireFits(encoded, 0, type(uint32).max);
        _requireFits(encoded, 2, type(uint160).max);
        _requireFits(encoded, 4, type(uint8).max);
        _requireFits(encoded, 5, type(uint64).max);
        _requireFits(encoded, 7, type(uint160).max);
        _requireFits(encoded, 8, type(uint160).max);
        _requireFits(encoded, 11, type(uint160).max);
        _requireFits(encoded, 12, type(uint160).max);
        _requireFits(encoded, 14, type(uint160).max);
        _requireFits(encoded, 15, type(uint160).max);
        _requireFits(encoded, 16, type(uint64).max);
        _requireFits(encoded, 17, type(uint64).max);

        replacement = abi.decode(encoded, (BandReplacement));
        validate(replacement);
    }

    function context() internal pure returns (bytes memory) {
        return abi.encodePacked(PQ_CONTEXT);
    }

    function structHash(BandReplacement memory replacement) internal pure returns (bytes32) {
        validate(replacement);
        return _structHashUnchecked(replacement);
    }

    function domainSeparator(uint256 chainId, address controller)
        internal
        pure
        returns (bytes32)
    {
        if (chainId == 0) revert InvalidChainId();
        if (controller == address(0)) revert InvalidController();
        return _domainSeparatorUnchecked(chainId, controller);
    }

    function walletDigest(BandReplacement memory replacement) internal pure returns (bytes32) {
        validate(replacement);
        return keccak256(
            abi.encodePacked(
                hex"1901",
                _domainSeparatorUnchecked(replacement.chainId, replacement.controller),
                _structHashUnchecked(replacement)
            )
        );
    }

    function _structHashUnchecked(BandReplacement memory replacement)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            abi.encode(
                REPLACEMENT_TYPEHASH,
                replacement.schemaVersion,
                replacement.chainId,
                replacement.controller,
                replacement.moduleId,
                replacement.actionType,
                replacement.authEpoch,
                replacement.nonce,
                replacement.manager,
                replacement.hook,
                replacement.poolId,
                replacement.oldVersion,
                replacement.oldMinSqrtPriceX96,
                replacement.oldMaxSqrtPriceX96,
                replacement.newVersion,
                replacement.newMinSqrtPriceX96,
                replacement.newMaxSqrtPriceX96,
                replacement.validAfter,
                replacement.validUntil,
                replacement.policyHash
            )
        );
    }

    function _domainSeparatorUnchecked(uint256 chainId, address controller)
        private
        pure
        returns (bytes32)
    {
        return keccak256(
            abi.encode(DOMAIN_TYPEHASH, NAME_HASH, VERSION_HASH, chainId, controller)
        );
    }

    function _validBand(uint160 minSqrtPriceX96, uint160 maxSqrtPriceX96)
        private
        pure
        returns (bool)
    {
        return minSqrtPriceX96 >= TickMath.MIN_SQRT_PRICE
            && minSqrtPriceX96 < maxSqrtPriceX96
            && maxSqrtPriceX96 < TickMath.MAX_SQRT_PRICE;
    }

    function _requireFits(bytes memory encoded, uint8 fieldIndex, uint256 maximum)
        private
        pure
    {
        uint256 word;
        assembly ("memory-safe") {
            word := mload(add(add(encoded, 0x20), mul(fieldIndex, 0x20)))
        }
        if (word > maximum) revert NonZeroPadding(fieldIndex);
    }
}
