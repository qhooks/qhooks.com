// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {PriceBandQController} from './PriceBandQController.sol';
import {IPoolManager} from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';
contract ConfiguredPriceBandController is PriceBandQController {
  constructor(address helper_, IPoolManager manager_, address owner_, bytes32 policyHash_,
    uint64 authEpoch_, bytes memory rawPublicKey_, address currency0_, address currency1_, bytes32 hookSalt_)
    PriceBandQController(helper_, manager_, owner_, policyHash_, authEpoch_, rawPublicKey_, currency0_, currency1_,
      3000, 60, 39614081257132168796771975168, 158456325028528675187087900672, hookSalt_) {
    require(block.chainid == 31337, 'Local chain only');
  }
}
