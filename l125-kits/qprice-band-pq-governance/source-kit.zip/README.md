Price Bands | QHooks
====================

Constrain swaps to a configured price band. Changing the band requires wallet and post-quantum approval.

Protected action: Price-band updates
Profile: ML-DSA-65

Source integration on local chain 31337. Use a compatible Uniswap v4 PoolManager, ordered ERC-20 currencies and the exact hook permission salt. Wallet and ML-DSA-65 authorization protect only the named action, not the EVM wallet, token transfers or every swap. Key enrollment has a separate, potentially substantial network cost. No automatic public-chain deployment or arbitrary hook combinations.

CONTENTS
- 64 Solidity files, including the configured wrapper and dependencies
- compiler-input.json: complete solc standard JSON input
- project.json: public configuration, requirements and source metadata
- SOURCE-INDEX.json: SHA-256 hashes for every other file in this ZIP
- Original third-party licenses and notices
- helper.json: pinned external helper bytecode and provenance (not built by this source input)

GET STARTED
1. Open https://qhooks.com/price-band-lab.html to configure your project and download a customized source/build package.
2. This starter uses local chain 31337. Repeated-digit addresses are placeholders, not destinations. Volume-window timestamps are fixed examples and must be replaced or matched by a disposable local clock. Raw amounts and sqrt-price bounds are not dollar values.
3. Use solc 0.8.26 with the included input:
   solc --standard-json < compiler-input.json > compiler-output.json
   Check the compiler errors array; a process exit alone does not establish compilation success.
4. Resolve your PoolManager, ordered token pair, fresh owner/key enrollment and exact CREATE2 permission salt. Follow all project.json requirements. Never reuse test keys or treat placeholder owners as onchain enforcement.
5. Exercise your chosen configuration and protected action in an isolated environment before separately reviewing any public-chain deployment. This download neither compiles nor deploys it.

PROFILE AND COST
This family uses ML-DSA-65. It is an optional, more expensive integration path; QGraduation uses the separate hash-based launch profile. Downloading/building does not incur an upfront hook purchase fee. Network costs, enrollment and any applicable trading fees are separate. No wallet connection, payment or transaction is requested by this kit.

REQUIREMENTS
- Initial pool fee, tick spacing and raw sqrt-price bounds are fixed by the generated controller. Project name is metadata only. Static fee1,000,000pips is100%; exact-output swaps at that fee are not usable.
- MIN_SQRT_PRICE<=minimum<maximum<MAX_SQRT_PRICE. Bounds are raw sqrt(token1 units/token0 units)*2^96, not dollar prices; token decimals matter.
- Pool initialization is permissionless at any price inside the inclusive initial band. Public swaps must finish inside the current inclusive band; liquidity callbacks are unaffected.
- Replacing the band requires the existing complete19-word wallet AND PQ authorization, a locked manager and inclusion of the current spot price. This is pool-local policy, not an oracle, anti-manipulation guarantee or LP-loss protection.
- Optional expensive ML-DSA-65 profile, not the cheaper hash-based default. Local chain31337 only. No deployment or network-fee estimate follows compilation.
- Supply a verified manager, pinned helper, EOA owner, nonzero policy hash, authorization epoch and enrolled1952-byte raw public key. Ordered distinct deployed ERC20s only. No private or test keys are included.
- Controller deployment creates its registry, verifier and hook. Find the CREATE2 salt for the actual controller address and full constructor-dependent child initcode with the declared permission flags.
- The helper is an artifact-pinned runtime with its accepted creation envelope, not reproduced from the included Solidity. Preserve notices; packaging does not settle production licensing obligations.
- Compiling a configuration is not its EVM behavior test or independent audit. No wallet/signing/enrollment, key rotation/recovery, automatic deployment, bridging or billing is enabled.

LICENSES
Retain all source headers and bundled notices. Different dependencies have different licenses; this package does not grant rights beyond those licenses or resolve production licensing obligations.
